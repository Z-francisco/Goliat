<?php 
    // Este archivo se usa en situaciones donde el estatus de los clientes sea incongruente en relacion con su cantidad restante de pagos, ejemplo:
    // a juan le queda por pagar 300 pero su cuenta tiene de estatus liquidada o viceversa, si juan no debe nada y aparece cuenta como cancelada o activa 

    include '../debug/headers.php';
    require_once '../debug/global_variables.php';
    require_once '../debug/global_sql_functions.php';
    require_once '../debug/global_functions.php';
    
    $db_general = $GLOBALS["datos_generales"];

    $matriz_clientes = paternalia_query(0, "SELECT * FROM $db_general.clientes");

    foreach ($matriz_clientes as $key) {
        
        if ($key['cantidadRestante'] > 0) {
            paternalia_query(1, "UPDATE $db_general.clientes SET estatus = '1' WHERE id = " . $key['id']);
            echo "se actualizó el estatus de " . $key['id'] ." a Activo\n";
        }else{
            paternalia_query(1, "UPDATE $db_general.clientes SET estatus = '2' WHERE id = " . $key['id']);
            echo "se actualizó el estatus de " . $key['id'] ." a Liquidado\n";
            $datos_cliente_liquidado = paternalia_query(0, "INSERT INTO goliat_paternalia.clientes_liquidados SELECT * FROM goliat_paternalia.clientes WHERE id = ". $key['id']);
            paternalia_query(1, "DELETE FROM goliat_paternalia.clientes WHERE id = ". $key['id']);
        }
        if (paternalia_query(4, "SELECT folio from $db_general.cancelaciones WHERE folio = " . $key['id']) > 0) {
            paternalia_query(1, "UPDATE $db_general.clientes SET estatus = '3' WHERE id = " . $key['id']);
            echo "se actualizó el estatus de " . $key['id'] ." a Cancelado\n";
        }
    }
?>