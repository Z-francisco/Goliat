<?php
// Angel Francisco Zamora Vazquez
// Goliat erp
// 2022

//SQL VARIABLES
$GLOBALS['host'] = 'localhost';
$GLOBALS['port'] = ':3306';
$GLOBALS['datos_generales'] = 'goliat_paternalia';
$GLOBALS['user'] = 'root';
$GLOBALS['password'] = '020410';

//VARIABLES ASSETS
$GLOBALS['images_url'] = 'http://192.168.100.127/apiGoliat/assets/image';
