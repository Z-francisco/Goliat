<?php
date_default_timezone_set('America/Mexico_City');
include '../../debug/headers.php';
require_once '../../debug/global_variables.php';
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';
require_once '../../vendor/autoload.php';
require_once '../../servicios/security/global_functions.php';

//SI EL IP NO ESTÁ REGISTRADO PUES SE LE MANDA ALV CON RESPETO
$ip = $_SERVER['REMOTE_ADDR'];
$personas_a_sacar_targeta = $_GET['ids'];
if (isLogued($ip) === 0) {
    echo 'No estás logueado, no tienes acceso a la informacion';
    exit();
    die;
}

function redondearSiDecimales($numero) {
    // Comprobamos si el número tiene decimales
    if (strpos($numero, '.') !== false) {
        // Convertimos el número a entero redondeando hacia arriba
        $numero = ceil($numero);
    }
    return $numero;
}

function numero_a_letra($numero)
{
    $base = 26;
    $letras = '';

    while ($numero > 0) {
        $modulo = ($numero - 1) % $base;
        $letras = chr(65 + $modulo) . $letras;
        $numero = intval(($numero - $modulo) / $base);
    }

    return $letras;
}

function num2alpha($n)
{
    for ($r = ""; $n >= 0; $n = intval($n / 26) - 1) {
        $r = chr($n % 26 + 0x41) . $r;
    }
    return $r;
}

function estilos($color_letra = '00000', $fondo = 'FFFFFF', $tamanio_letra = 12, $tipo_letra = 'Arial', $bordes = false, $align = 'left')
{
    $estilos = array(
        'font' => array(
            'name' => $tipo_letra,
            'size' => $tamanio_letra,
            'color' => array(
                'rgb' => $color_letra,
            ),
        ),
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array(
                'rgb' => $fondo,
            ),
        ),
        'alignment' => array(
            'horizontal' => $align,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
        ),
    );

    if ($bordes) {
        $estilos['borders'] = array(
            'allborders' => array(
                'style' => PHPExcel_Style_Border::BORDER_THIN,
            ),
        );
    }
    return $estilos;
}

$query_clientes = paternalia_query(1, "SELECT c.id, c.nombre, c.direccion, c.costoTotal, c.numero, c.fepe, c.numerodequin, p.anio, p.mes, p.dia FROM goliat_paternalia.clientes c
                                       JOIN goliat_paternalia.pagos p on p.folioRelacionado = c.id and p.concepto = 'Primer pago'
                                       where c.id in ($personas_a_sacar_targeta)");

$objPHPExcel = new PHPExcel();

$celeste_bg = estilos('000000', '32cdcc', 10, 'Calibri', false);
$amarillo_bg = estilos('000000', 'fefe99', 10, 'Calibri', false);
$azul_bg = estilos('000000', '01b0f1', 10, 'Calibri', false, 'center');
$cielo_bg = estilos('000000', '00ffff', 10, 'Calibri', false, 'center');
$cielo_nublado_bg = estilos('000000', '32cdcc', 10, 'Calibri', false);
$cielo_nublado_C_bg = estilos('000000', '32cdcc', 10, 'Calibri', false, 'center');
$verde_bg = estilos('000000', '99fe98', 10, 'Calibri', false, 'center');
$rosa_bg = estilos('000000', 'fe99fe', 10, 'Calibri', false, 'center');
$rosa_y_motivacion_bg = estilos('000000', 'fe99fe', 6, 'Calibri', false, 'justify');
$header_styles = estilos('000000', 'ffffff', 10, 'Calibri', true);
$columnas_styles = estilos('000000', 'ffffff', 10, 'Calibri', true, 'center');

/* $objPHPExcel->getActiveSheet()->getRowDimension(1)->setRowHeight(30);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('A')->setWidth(5.45);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('B')->setWidth(35);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('D')->setWidth(13);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('E')->setWidth(13);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('F')->setWidth(13); */


// RECORRE LAS PRIMERAS 4 LETRAS PARA PONER EL ANCHO DESEADO
$set_number_alpha = range(1, 14);
foreach ($set_number_alpha as $key) {
    $objPHPExcel->setActiveSheetIndex()->getColumnDimension(numero_a_letra($key))->setWidth(11.304);
}
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('E')->setWidth(0.5);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('J')->setWidth(0.5);


$fila_inicial = 3;
$inicio_contenido = 1;

// Obtener todos los registros en un arreglo
$arreglo_clientes = mysqli_fetch_all($query_clientes, MYSQLI_ASSOC);

// Ordenar el arreglo por la fecha
usort($arreglo_clientes, function ($a, $b) {
    return strtotime($a['fepe']) - strtotime($b['fepe']);
});

$style = array(
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'vertical' => 'center',
    )
);

$letra_usada = 1;
$ciclos = 0;
$gdImage = imagecreatefromjpeg('http://192.168.100.127/apiGoliat/assets/image/logo.jpg');


$divisible_entre_tres = count($arreglo_clientes) / 3;
$a_sumar = redondearSiDecimales($divisible_entre_tres);
$suma_total_r = $a_sumar * 33;

$set_number_height = range(1, $suma_total_r);
foreach ($set_number_height as $key) {
    $objPHPExcel->getActiveSheet()->getRowDimension($key)->setRowHeight(17.28);
}

$objPHPExcel->getActiveSheet()->getStyle(numero_a_letra(($letra_usada)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 13)) . ($fila_inicial + $suma_total_r))->applyFromArray($header_styles);
// Iterar sobre el arreglo ordenado
foreach ($arreglo_clientes as $arreglo_clientes_item) {
    /*     $query_pagos = paternalia_query(1, "SELECT id FROM goliat_paternalia.pagos WHERE folioRelacionado=" . $arreglo_clientes_item['id']); */
    if ($ciclos != 0 && $ciclos % 3 == 0) {
        // Hacer algo si es múltiplo de 3
        $fila_inicial += 27;
        $letra_usada -= 15;
    }
    if ($ciclos % 3 != 0) {
        $fila_inicial -= 7;
    }
    $fila_imagen = ($fila_inicial - 2);
    $letra_final_imagen = ($fila_inicial - 1);

    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra($letra_usada).$fila_imagen.':'.numero_a_letra(($letra_usada+3)).($fila_imagen+1));

    
    // Add a drawing to the worksheetecho date('H:i:s') . " Add a drawing to the worksheet\n";
    
    $objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
    $objDrawing->setName('Sample image');
    $objDrawing->setDescription('Sample image');
    $objDrawing->setImageResource($gdImage);
    $objDrawing->setOffsetX(70);
    $objDrawing->setOffsetY(5);
    $objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
    $objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
    $objDrawing->setCoordinates(numero_a_letra($letra_usada).$fila_imagen);
    $objDrawing->setHeight(39);
    $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());

    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada) . $fila_inicial, 'NOMBRE:'.count($arreglo_clientes));
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada + 1) . $fila_inicial, 'ㅤ'.$arreglo_clientes_item['nombre']);
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada + 1)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra($letra_usada) . $fila_inicial . ':' . numero_a_letra(($letra_usada)) . $fila_inicial)->applyFromArray($celeste_bg);
    $fila_inicial++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada) . $fila_inicial, 'DIRECCIÓN:');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada + 1) . $fila_inicial, 'ㅤ'.$arreglo_clientes_item['direccion']);
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada + 1)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial);
    $fila_inicial++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada) . $fila_inicial, 'TELÉFONO:');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada + 1) . $fila_inicial, 'ㅤ'.$arreglo_clientes_item['numero']);
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada + 1)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial);
    $fila_inicial++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada) . $fila_inicial, 'CUENTA:');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada + 1) . $fila_inicial, 'ㅤT-'.$arreglo_clientes_item['id']);
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada + 1)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra($letra_usada) . $fila_inicial . ':' . numero_a_letra(($letra_usada)) . $fila_inicial)->applyFromArray($amarillo_bg);
    $fila_inicial++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada)) . $fila_inicial, 'INICIO DE CRÉDITO:');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada + 2) . $fila_inicial, 'ㅤ'.$arreglo_clientes_item['fepe']);
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada + 2)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial);
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra($letra_usada) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 1)) . $fila_inicial);
    $fila_inicial++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada)) . $fila_inicial, 'TÉRMINO DE CRÉDITO:');
    //PONER EL FINAL DE CREDITO, ESTO CON AYUDA DE PREDICCION DE PAGOS ARCHIVO PHP
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada + 2)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial);
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra($letra_usada) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 1)) . $fila_inicial);
    $fila_inicial++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada) . $fila_inicial, 'IMPORTE:');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada + 1) . $fila_inicial, 'ㅤ$'.$arreglo_clientes_item['costoTotal']);
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada + 1)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra($letra_usada) . $fila_inicial . ':' . numero_a_letra(($letra_usada)) . $fila_inicial)->applyFromArray($amarillo_bg);
    $fila_inicial++;
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada) . $fila_inicial, 'PROMESA');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada + 1)) . $fila_inicial, 'FECHA');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada + 2)) . $fila_inicial, 'PAGO');
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada + 3)) . $fila_inicial, 'SALDO');

    $fechas_pago_cliente = generarFechasDePagos($arreglo_clientes_item['anio'].'-'.$arreglo_clientes_item['mes'].'-'.$arreglo_clientes_item['dia'], ($arreglo_clientes_item['numerodequin']/2));
    $pagos_realizados_cliente = paternalia_query(0, "SELECT * from pagos where folioRelacionado = ".$arreglo_clientes_item['id']);
    $variable_p_sumar = 1;
    foreach ($pagos_realizados_cliente as $prc) {
        $restante = $arreglo_clientes_item['costoTotal'];
        $restante  -=$prc['cantidad'];
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada+1)) . ($fila_inicial + $variable_p_sumar), $prc['dia'].'-'.$prc['mes'].'-'.$prc['anio']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada+2)) . ($fila_inicial + $variable_p_sumar), $prc['cantidad']);
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada+3)) . ($fila_inicial + $variable_p_sumar), $restante);
        $variable_p_sumar++;
    }
    $variable_p_sumar -= count($pagos_realizados_cliente);
    foreach ($fechas_pago_cliente as $fpc) {
        $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra($letra_usada) . ($fila_inicial + $variable_p_sumar), $fpc);
        $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra($letra_usada) . ($fila_inicial+1).':'.numero_a_letra($letra_usada+3) . ($fila_inicial+22))->applyFromArray($style);
        $variable_p_sumar++;
    }

    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada)) . ($fila_inicial + 22), 'La EDUCACIÓN es nuestro pasaporte para nuestro FUTURO por que el mañana pertenece a la gente que se prepara para el HOY');
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada)) . ($fila_inicial + 22) . ':' . numero_a_letra(($letra_usada + 3)) . ($fila_inicial + 22));
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada)) . ($fila_inicial + 23), 'DUDAS Y ACLARACIONES');
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada)) . ($fila_inicial + 23) . ':' . numero_a_letra(($letra_usada + 3)) . ($fila_inicial + 23));
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada)) . ($fila_inicial + 24), '2221488558');
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra(($letra_usada + 2)) . ($fila_inicial + 24) . ':' . numero_a_letra(($letra_usada + 3)) . ($fila_inicial + 24));
    $objPHPExcel->setActiveSheetIndex(0)->setCellValue(numero_a_letra(($letra_usada + 2)) . ($fila_inicial + 24), '2227731344');
    $objPHPExcel->setActiveSheetIndex(0)->mergeCells(numero_a_letra($letra_usada) . ($fila_inicial + 24) . ':' . numero_a_letra(($letra_usada + 1)) . ($fila_inicial + 24));

    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra($letra_usada) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial)->applyFromArray($columnas_styles);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra(($letra_usada)) . $fila_inicial . ':' . numero_a_letra(($letra_usada)) . $fila_inicial)->applyFromArray($azul_bg);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra(($letra_usada + 1)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 1)) . $fila_inicial)->applyFromArray($verde_bg);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra(($letra_usada + 2)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 2)) . $fila_inicial)->applyFromArray($cielo_bg);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra(($letra_usada + 3)) . $fila_inicial . ':' . numero_a_letra(($letra_usada + 3)) . $fila_inicial)->applyFromArray($rosa_bg);

    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra(($letra_usada)) . ($fila_inicial + 22) . ':' . numero_a_letra(($letra_usada + 3)) . ($fila_inicial + 22))->applyFromArray($rosa_y_motivacion_bg);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra(($letra_usada)) . ($fila_inicial + 23) . ':' . numero_a_letra(($letra_usada + 3)) . ($fila_inicial + 23))->applyFromArray($cielo_nublado_C_bg);
    $objPHPExcel->getActiveSheet()->getStyle(numero_a_letra(($letra_usada)) . ($fila_inicial + 24) . ':' . numero_a_letra(($letra_usada + 3)) . ($fila_inicial + 24))->applyFromArray($cielo_bg);

    $letra_usada += 5;

    $ciclos++;
}


$fila_inicial = 2;

$objPHPExcel->getActiveSheet()->setTitle('Ventas activas');
$objPHPExcel->setActiveSheetIndex(0);

// Crea el objeto Writer para Excel 2007
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

// Establece las cabeceras para descargar el archivo
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Reporte General.xlsx"');
header('Cache-Control: max-age=0');

// Descarga el archivo
$objWriter->save('php://output');
exit;
