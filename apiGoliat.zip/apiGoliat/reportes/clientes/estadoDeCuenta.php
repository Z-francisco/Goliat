<?php
header("Access-Control-Allow-Origin: *");
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';
if (isset($_GET["edocta"])) {
    ob_start();
}
$fila = 1;
$cliente = paternalia_query(0, "SELECT * FROM $db_general.clientes WHERE id = " . $_GET["edocta"] . " UNION SELECT * FROM $db_general.clientes_liquidados WHERE id = " . $_GET["edocta"]);
$pagos_cliente = paternalia_query(0, "SELECT * FROM " . $GLOBALS['datos_generales'] . ".pagos WHERE folioRelacionado = " . $_GET["edocta"]);

function compararFechas($a, $b) {
    $fechaA = strtotime($a['anio'] . '-' . $a['mes'] . '-' . $a['dia']);
    $fechaB = strtotime($b['anio'] . '-' . $b['mes'] . '-' . $b['dia']);
    return $fechaA - $fechaB;
}


usort($pagos_cliente, 'compararFechas');

$estado = comparacion($cliente[0]['cantidadRestante'], 0, 'igual');
$zamora = floatval($cliente[0]['costoTotal']);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <caption>Estado de cuenta: <?php echo $estado ?></caption>

    <div class="table-responsive">
        <table class="table table-primary">
            <thead>
                <tr>
                    <td scope="row">Folio de cuenta: <?php echo 'T-' . $cliente[0]['id'] ?></td>
                </tr>
            </thead>
            <tbody>
                <tr class="">
                    <td scope="row">Nombre: <?php echo $cliente[0]['nombre'] ?></td>
                </tr>
                <tr class="">
                    <td scope="row">Cantidad inicial: <?php echo '$' . $cliente[0]['costoTotal'] ?></td>
                </tr>
                <tr class="">
                    <td scope="row">Cantidad restante: <?php echo '$' . $cliente[0]['cantidadRestante'] ?></td>
                </tr>
                <img src="https://paternalia.com/apiGoliat/assets/image/logo.png" height="70px" style="position: absolute; margin-left: 73%; margin-top: -134px;">
            </tbody>
        </table>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-hover table-borderless table-primary align-middle">
            <thead class="table-success">
                <style>
                    * {
                        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
                    }
                </style>

                <tr>
                    <th>No. de pago</th>
                    <th>Importe</th>
                    <th>Fecha</th>
                    <th>Motivo</th>
                    <th>Cantidad</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php foreach ($pagos_cliente as $pagos) { ?>
                    <tr class="table-primary">
                        <td scope="row"><?php echo $fila; ?></td>
                        <td>$<?php echo $pagos['cantidad']; ?></td>
                        <td><?php echo $pagos['dia'] . '-' . $pagos['mes'] . '-' . $pagos['anio']; ?></td>
                        <td><?php echo $pagos['concepto']; ?></td>
                        <td>
                            <?php
                            $zamora = $zamora - $pagos['cantidad'];
                            echo '$'.$zamora;
                            ?>
                        </td>
                    </tr>
                <?php $fila++;
                } ?>
            </tbody>
            <tfoot>
            </tfoot>
        </table>
    </div>

</body>

</html>

<?php
$html = ob_get_clean();

require_once '../../vendor/autoload.php';

use Dompdf\Dompdf;

$dompdf = new Dompdf();
$options = $dompdf->getOptions();
$options->set(array('isRemoteEnabled' => true));
$dompdf->loadhtml($html);
$dompdf->setPaper('Letter');
$dompdf->render();
$dompdf->stream($cliente[0]['nombre'], array('Attachment' => false));
?>