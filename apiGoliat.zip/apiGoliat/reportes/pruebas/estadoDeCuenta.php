<?php
header("Access-Control-Allow-Origin: *");
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';
$arrray = paternalia_query(0, "SELECT * from goliat_paternalia.clientes WHERE id = 1");

print_r($arrray);
echo "<br>";
echo json_encode("INSERT INTO goliat_paternalia.clientes_liquidados values ");
