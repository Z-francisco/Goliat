<?php
include_once '../../debug/headers.php';
include_once '../../debug/global_variables.php';
include_once '../../debug/global_sql_functions.php';
require_once '../security/jwt.php';

$jwt = $_GET['jwt'];    

if (verifyJWT($jwt) === false) {
    die;
}


$db_general = $GLOBALS["datos_generales"];
$data = json_decode(file_get_contents("php://input"), true);

$connect = new mysqli($GLOBALS['host'].$GLOBALS['port'], $GLOBALS['user'], $GLOBALS['password'], $GLOBALS['datos_generales']);

//Consulta el historial de ingresos-egresos de almacen
if (isset($_GET["consulta"])) {
    paternalia_query(2, "SELECT * FROM $db_general.almacen");
}

//Registro de nuevo elemento para el almacen
if (isset($_GET["nuevo"])) {
    extract($data);
    if ($nombre != '' && $clave != '') {
        if (paternalia_query(4, "SELECT clave_mat FROM $db_general.almacen WHERE clave_mat = $clave") > 0) {
            echo json_encode(['respuesta' => 'Hay un registro con una clave igual', "tipo" => 'warning']);
            exit();
        }else{
            paternalia_query(1, "INSERT INTO $db_general.almacen(nombre_mat, clave_mat) VALUES('$nombre','$clave')");
            echo json_encode(['respuesta' => 'Se ha creado el producto', "tipo" => 'success']);
        }
    }else{
        echo json_encode(['respuesta' => 'Datos insuficientes', "tipo" => 'warning']);
    }
    
    exit();
}

//Hacer ingreso de almacen y hace su historial
if (isset($_GET["ingreso"])) {
    $id = (isset($data->id)) ? $data->id : $_GET["ingreso"];
    $mat = $data->mat;
    $cantidad = $data->cantidad;
    $totalsumado = 0;
    $sql2 = "SELECT * FROM $db_general.almacen WHERE clave_mat='$mat'";
    $result = mysqli_query($connect, $sql2);

    while ($mostrar = mysqli_fetch_array($result)) {
        $nmb_mat = $mostrar['nombre_mat'];
        $canti = $mostrar['cantidad_mat'];
        $enpedido = $mostrar['en_pedido'];
        $enventa = $mostrar['en_venta'];
    }

    $totalsumado = $canti + $cantidad;
    if (($mat != "" && $cantidad != "")) {
        $sql_goliat_act = mysqli_query($connect, "UPDATE $db_general.almacen set cantidad_mat='$totalsumado' WHERE clave_mat='$mat';");
        $Generar_historial = mysqli_query($connect, "INSERT INTO $db_general.historial VALUES ('$nmb_mat','+$cantidad',curdate())");
        exit();
    }
    exit();
}

//Hacer egreso del almacen y hace su historial
if (isset($_GET["egreso"])) {
    $id = (isset($data->id)) ? $data->id : $_GET["ingreso"];
    $mat = $data->mat;
    $cantidad = $data->cantidad;
    $totalsumado = 0;
    $sql2 = "SELECT * FROM $db_general.almacen WHERE clave_mat='$mat'";
    $result = mysqli_query($connect, $sql2);

    while ($mostrar = mysqli_fetch_array($result)) {
        $nmb_mat = $mostrar['nombre_mat'];
        $canti = $mostrar['cantidad_mat'];
        $enpedido = $mostrar['en_pedido'];
        $enventa = $mostrar['en_venta'];
    }

    $totalsumado = $canti - $cantidad;
    if (($mat != "" && $cantidad != "")) {
        $sql_goliat_act = mysqli_query($connect, "UPDATE $db_general.almacen set cantidad_mat='$totalsumado' WHERE clave_mat='$mat';");
        $Generar_historial = mysqli_query($connect, "INSERT INTO $db_general.historial VALUES ('$nmb_mat','-$cantidad',curdate())");
        exit();
    }
    exit();
}

$sqlEmpleaados = mysqli_query($connect, "SELECT * FROM $db_general.almacen ");
if (mysqli_num_rows($sqlEmpleaados) > 0) {
    $empleaados = mysqli_fetch_all($sqlEmpleaados, MYSQLI_ASSOC);
    echo json_encode($empleaados);
} else {
    echo json_encode([["success" => 0]]);
}
