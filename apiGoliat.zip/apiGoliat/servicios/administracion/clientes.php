<?php 
include_once '../../debug/headers.php';
include_once '../../debug/global_variables.php';
include_once '../../debug/global_sql_functions.php';
require_once '../security/jwt.php';

$jwt = $_GET['jwt'];    

if (verifyJWT($jwt) === false) {
    die;
}

$db_general = $GLOBALS["datos_generales"];
$data = json_decode(file_get_contents("php://input"), true);

//consulta un registro por medio de algun parametro
if (isset($_GET["consultar"])) {
    $cliente = paternalia_query(0, "SELECT * FROM $db_general.clientes WHERE id = " . $_GET["consultar"] . " UNION SELECT * FROM $db_general.clientes_liquidados WHERE id = " . $_GET["consultar"]);
    // Transformar el campo "material" en un array de objetos
    $material = explode(',', $cliente[0]['material']);
    $materialArray = [];

    foreach ($material as $item) {
        // Consultar los datos del material desde $db_general.almacen usando la clave_mat
        $materialData = paternalia_query(3, "SELECT clave_mat, nombre_mat FROM $db_general.almacen WHERE clave_mat = $item");
        if ($materialData) {
            $materialArray[] = $materialData;
        }
    }

    // Reemplazar el campo "material" con el nuevo array de objetos
    $cliente[0]['material'] = $materialArray;

    // Devolver los datos transformados en formato JSON
    echo json_encode($cliente);
    exit();
}
if (isset($_GET["esCancelado"])) {
    $id = isset($data['id']) ? $data['id'] : $_GET["esCancelado"];
    echo json_encode([
        'esCancelado' => mysqli_num_rows(paternalia_query(1, "SELECT id FROM $db_general.clientes where id = $id and estatus = 3"))
    ]);
    exit();
}
if (isset($_GET["cancelar"])) {
    $id = isset($data['id']) ? $data['id'] : $_GET["cancelar"];
    extract($data);
    $material_en_texto = implode(',', array_column($material, 'clave_mat'));
    $cancelar = paternalia_query(1, "UPDATE $db_general.clientes SET estatus = 3 WHERE id = $id");
    if ($cancelar>0) {
        paternalia_query(1, "INSERT INTO $db_general.cancelaciones(folio, fecha, calidad, penalizacion, material) VALUES('$id', '$fecha', '$calidad', '$penalizacion', '$material_en_texto')");
        echo json_encode(['respuesta' => 'Se ha cancelado con éxito', "tipo" => 'success']);
    }else{
        echo json_encode(['respuesta' => 'Ha ocurrido un error', "tipo" => 'error']);
    }
    exit();
}

if (isset($_GET['reactivar'])) {
    $id = isset($data['id']) ? $data['id'] : $_GET["reactivar"];
    $reactivaQuery = paternalia_query(1, "UPDATE $db_general.clientes SET estatus = 1 where id = $id");
    if ( $reactivaQuery > 0 ){
        echo json_encode(['respuesta' => 'Se ha reactivado con éxito', "tipo" => 'success']);
        paternalia_query(1, "DELETE FROM $db_general.cancelaciones where folio = $id");
    }
}
if (isset($_GET["actualizar"])) {

    $id = isset($data['id']) ? $data['id'] : $_GET["actualizar"];
    extract($data);

    $material_en_texto = implode(',', array_column($material, 'clave_mat'));

    if (paternalia_query(1, "UPDATE $db_general.clientes SET nombre='$nombre', direccion = '$direccion', numero = '$numero', municipio = '$municipio', costoTotal = '$costoTotal', lapsodedias = '$lapsodedias', numerodequin = '$numerodequin', cantidadRestante = '$cantidadRestante', aportacionInicial = '$aportacionInicial', formpago = '$formpago', material = '$material_en_texto', clientejob = '$clientejob', nombreesposo = '$nombreesposo', esposojob = '$esposojob', esposonro = '$esposonro', ninonmb = '$ninonmb', ninogg = '$ninogg', escuelanino = '$escuelanino', rf1nmb = '$rf1nmb', rf1direcc = '$rf1direcc', rf1nro = '$rf1nro', rf1parent ='$rf1parent' WHERE id=$id") > 0) {
        echo json_encode(['respuesta' => 'Los datos han sido modificados con éxito', "tipo" => 'success']);
    }else{
        echo json_encode(['respuesta' => 'Ha ocurrido un error', "tipo" => 'error']);
    }
    exit();
}
if (isset($_GET["consulta"])) {
    if ($_GET["consulta"] == 3) {
        $all_customers = paternalia_query(0, 
            "SELECT c.id, c.nombre, c.numero, c.cantidadRestante, c.costoTotal, c.material, cec.estatus_nombre as estatus, cec.estatus_color 
            FROM $db_general.clientes c 
            LEFT JOIN $db_general.cat_estatus_clientes cec 
            ON cec.id_estatus = c.estatus and cec.estatus = 1 WHERE c.estatus = 3"
        );
        echo json_encode(["clientes" => $all_customers, "pagos" => consulta_pagos()]);
    }
    if ($_GET["consulta"] == 2) {
        $all_customers = paternalia_query(0, 
            "SELECT c.id, c.nombre, c.numero, c.cantidadRestante, c.costoTotal, c.material, cec.estatus_nombre as estatus, cec.estatus_color 
            FROM $db_general.clientes_liquidados c 
            LEFT JOIN $db_general.cat_estatus_clientes cec 
            ON cec.id_estatus = c.estatus and cec.estatus = 1 WHERE c.estatus = 2"
        );
        echo json_encode(["clientes" => $all_customers, "pagos" => consulta_pagos()]);
    }
    if ($_GET["consulta"] == 1) {
        $all_customers = paternalia_query(0, 
            "SELECT c.id as id, c.nombre, c.numero, c.cantidadRestante, c.costoTotal, c.material, cec.estatus_nombre as estatus, cec.estatus_color 
            FROM clientes c 
            LEFT JOIN cat_estatus_clientes cec 
            ON cec.id_estatus = c.estatus and cec.estatus = 1 WHERE c.estatus = 1"
        );
        echo json_encode(["clientes" => $all_customers, "pagos" => consulta_pagos()]);
    }
    exit();
}
