<?php
include_once '../../debug/headers.php';
include_once '../../debug/global_variables.php';
include_once '../../debug/global_sql_functions.php';
require_once '../security/jwt.php';

$jwt = $_GET['jwt'];    

if (verifyJWT($jwt) === false) {
    die;
}

$db_general = $GLOBALS["datos_generales"];
$data = json_decode(file_get_contents("php://input"), true);

if (isset($_GET["consultar"])) {
    $id = isset($data['id']) ? $data['id'] : $_GET["consultar"];
    echo paternalia_query(2, "SELECT * FROM $db_general.tr_vendedores WHERE vendedor_id = $id");
    exit();
}

if (isset($_GET["insertar"])) {
    extract($data);
    if ($nombre != '' && $numero_tel != '' && $rfc != '' && $comision != '') {
        $insercion = paternalia_query(1, 
        "INSERT INTO $db_general.tr_vendedores(nombre, primer_apellido, segundo_apellido, numero_tel, rfc, ref_bancaria, direccion, comision) 
        VALUES('$nombre', '$primer_apellido', '$segundo_apellido', '$numero_tel', '$rfc', '$ref_bancaria', '$direccion', '$comision')");
        if (!empty($insercion)) {
            echo json_encode(['respuesta' => 'Has registrado al nuevo vendedor con exito :)', "tipo" => 'success']);
        }else{
            echo json_encode(['respuesta' => 'Ha ocurrido un error, si el problema persiste contacte a soporte', "tipo" => 'error']);
        }
    }
    exit();
}
if (isset($_GET["modificar"])) {
    $id = isset($data['id']) ? $data['id'] : $_GET["modificar"];
    extract($data);

    if (paternalia_query(1, "UPDATE $db_general.tr_vendedores SET nombre='$nombre',primer_apellido='$primer_apellido',segundo_apellido='$segundo_apellido',numero_tel='$numero_tel',rfc='$rfc',ref_bancaria='$ref_bancaria',direccion='$direccion',comision='$comision' WHERE vendedor_id='$id'")) {
        echo json_encode(["respuesta" => 'Los datos han sido modificados con éxito', "tipo" => 'success']);
    }
    exit();
}

if (isset($_GET["consulta"])) {
    if ($_GET["consulta"] == '020410') {
        echo paternalia_query(2, "SELECT vendedor_id, nombre, primer_apellido, segundo_apellido, numero_tel, direccion, situacion_id FROM $db_general.tr_vendedores WHERE estatus = 1");
    }
    exit();
}
