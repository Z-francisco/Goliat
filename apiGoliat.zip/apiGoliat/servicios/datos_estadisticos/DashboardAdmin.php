<?php
include_once '../../debug/headers.php';
include_once '../../debug/global_sql_functions.php';
include_once '../../servicios/security/jwt.php';

$jwt = $_GET['jwt'];

if (verifyJWT($jwt) === false) {
    die;
}

$anio = $_GET['anio'];
$mes = $_GET['mes'];

// Estadisticas ventas por mes, (anuales) año recibido
$query = "
    SELECT 
    SUM(CASE WHEN fepe LIKE '$anio-01-%' THEN 1 ELSE 0 END) as ventas_enero,
    SUM(CASE WHEN fepe LIKE '$anio-01-%' THEN costoTotal ELSE 0 END) as costoTotal_enero,
    SUM(CASE WHEN fepe LIKE '$anio-02-%' THEN 1 ELSE 0 END) as ventas_febrero,
    SUM(CASE WHEN fepe LIKE '$anio-02-%' THEN costoTotal ELSE 0 END) as costoTotal_febrero,
    SUM(CASE WHEN fepe LIKE '$anio-03-%' THEN 1 ELSE 0 END) as ventas_marzo,
    SUM(CASE WHEN fepe LIKE '$anio-03-%' THEN costoTotal ELSE 0 END) as costoTotal_marzo,
    SUM(CASE WHEN fepe LIKE '$anio-04-%' THEN 1 ELSE 0 END) as ventas_abril,
    SUM(CASE WHEN fepe LIKE '$anio-04-%' THEN costoTotal ELSE 0 END) as costoTotal_abril,
    SUM(CASE WHEN fepe LIKE '$anio-05-%' THEN 1 ELSE 0 END) as ventas_mayo,
    SUM(CASE WHEN fepe LIKE '$anio-05-%' THEN costoTotal ELSE 0 END) as costoTotal_mayo,
    SUM(CASE WHEN fepe LIKE '$anio-06-%' THEN 1 ELSE 0 END) as ventas_junio,
    SUM(CASE WHEN fepe LIKE '$anio-06-%' THEN costoTotal ELSE 0 END) as costoTotal_junio,
    SUM(CASE WHEN fepe LIKE '$anio-07-%' THEN 1 ELSE 0 END) as ventas_julio,
    SUM(CASE WHEN fepe LIKE '$anio-07-%' THEN costoTotal ELSE 0 END) as costoTotal_julio,
    SUM(CASE WHEN fepe LIKE '$anio-08-%' THEN 1 ELSE 0 END) as ventas_agosto,
    SUM(CASE WHEN fepe LIKE '$anio-08-%' THEN costoTotal ELSE 0 END) as costoTotal_agosto,
    SUM(CASE WHEN fepe LIKE '$anio-09-%' THEN 1 ELSE 0 END) as ventas_septiembre,
    SUM(CASE WHEN fepe LIKE '$anio-09-%' THEN costoTotal ELSE 0 END) as costoTotal_septiembre,
    SUM(CASE WHEN fepe LIKE '$anio-10-%' THEN 1 ELSE 0 END) as ventas_octubre,
    SUM(CASE WHEN fepe LIKE '$anio-10-%' THEN costoTotal ELSE 0 END) as costoTotal_octubre,
    SUM(CASE WHEN fepe LIKE '$anio-11-%' THEN 1 ELSE 0 END) as ventas_noviembre,
    SUM(CASE WHEN fepe LIKE '$anio-11-%' THEN costoTotal ELSE 0 END) as costoTotal_noviembre,
    SUM(CASE WHEN fepe LIKE '$anio-12-%' THEN 1 ELSE 0 END) as ventas_diciembre,
    SUM(CASE WHEN fepe LIKE '$anio-12-%' THEN costoTotal ELSE 0 END) as costoTotal_diciembre
FROM clientes
";

// Se ejecuta la consulta a la base de datos
$results = paternalia_query(0, $query);

// Se establece el array data para usarse directamente con Chart.js
$dataAnual = [
    'labels' => ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
    'datasets' => [
        [
            'borderRadius' => 5,
            'label' => 'Ventas',
            'data' => [
                $results[0]['ventas_enero'], 
                $results[0]['ventas_febrero'], 
                $results[0]['ventas_marzo'], 
                $results[0]['ventas_abril'], 
                $results[0]['ventas_mayo'], 
                $results[0]['ventas_junio'], 
                $results[0]['ventas_julio'], 
                $results[0]['ventas_agosto'], 
                $results[0]['ventas_septiembre'], 
                $results[0]['ventas_octubre'], 
                $results[0]['ventas_noviembre'], 
                $results[0]['ventas_diciembre']],
            'backgroundColor' => [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
            ],
            'borderColor' => [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
            ],
            'borderWidth' => 1,
        ], [
            'borderRadius' => 5,
            'label' => 'Importe',
            'data' =>  [
                $results[0]['costoTotal_enero'], 
                $results[0]['costoTotal_febrero'], 
                $results[0]['costoTotal_marzo'], 
                $results[0]['costoTotal_abril'], 
                $results[0]['costoTotal_mayo'], 
                $results[0]['costoTotal_junio'], 
                $results[0]['costoTotal_julio'], 
                $results[0]['costoTotal_agosto'], 
                $results[0]['costoTotal_septiembre'], 
                $results[0]['costoTotal_octubre'], 
                $results[0]['costoTotal_noviembre'], 
                $results[0]['costoTotal_diciembre']],
            'backgroundColor' => [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)',
            ],
            'borderColor' => [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)',
            ],
            'borderWidth' => 1,
        ],
    ],
];

// Estadisticas ventas por quincena, (mensual) mes recibido
$queryQuincena = "
    SELECT 
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-01' AND '$anio-$mes-15' THEN 1 ELSE 0 END) as primera_quincena,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-16' AND '$anio-$mes-31' THEN 1 ELSE 0 END) as segunda_quincena,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-01' AND '$anio-$mes-15' THEN costoTotal ELSE 0 END) as costoTotal_primera,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-16' AND '$anio-$mes-31' THEN costoTotal ELSE 0 END) as costoTotal_segunda
    FROM clientes
";

// Se ejecuta la consulta a la base de datos
$results = paternalia_query(0, $queryQuincena);

// Se establece el array data para usarse directamente con Chart.js
$dataQuincenal = [
    'labels' => ['Dia 01 al 15', 'Dia 16 al 31'],
    'datasets' => [
        [
            'borderRadius' => 5,
            'label' => 'Ventas',
            'data' => [
                $results[0]['primera_quincena'], 
                $results[0]['segunda_quincena']],
            'backgroundColor' => [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
            ],
            'borderColor' => [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
            ],
            'borderWidth' => 1,
        ], [
            'borderRadius' => 5,
            'label' => 'Importe',
            'data' => [
                $results[0]['costoTotal_primera'], 
                $results[0]['costoTotal_segunda']],
            'backgroundColor' => [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
            ],
            'borderColor' => [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
            ],
            'borderWidth' => 1,
        ],
    ],
];
// Estadisticas ventas por semanales, (mensual) mes actual
$querySemana = "
    SELECT 
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-01' AND '$anio-$mes-07' THEN 1 ELSE 0 END) as primera_semana,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-01' AND '$anio-$mes-07' THEN costoTotal ELSE 0 END) as primera_semana_costoTotal,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-08' AND '$anio-$mes-14' THEN 1 ELSE 0 END) as segunda_semana,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-08' AND '$anio-$mes-14' THEN costoTotal ELSE 0 END) as segunda_semana_costoTotal,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-15' AND '$anio-$mes-22' THEN 1 ELSE 0 END) as tercera_semana,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-15' AND '$anio-$mes-22' THEN costoTotal ELSE 0 END) as tercera_semana_costoTotal,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-23' AND '$anio-$mes-31' THEN 1 ELSE 0 END) as cuarta_semana,
        SUM(CASE WHEN fepe BETWEEN '$anio-$mes-23' AND '$anio-$mes-31' THEN costoTotal ELSE 0 END) as cuarta_semana_costoTotal
    FROM clientes
";


// Se ejecuta la consulta a la base de datos
$results = paternalia_query(0, $querySemana);

// Se establece el array data para usarse directamente con Chart.js
$dataSemanal = [
    'labels' => ['Dia 01 al 07', 'Dia 08 al 14', 'Dia 15 al 22', 'Dia 23 al 31'],
    'datasets' => [
        [
            'borderRadius' => 5,
            'label' => 'Ventas',
            'data' => [
                $results[0]['primera_semana'], 
                $results[0]['segunda_semana'], 
                $results[0]['tercera_semana'], 
                $results[0]['cuarta_semana']],
            'backgroundColor' => [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
            ],
            'borderColor' => [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
            ],
            'borderWidth' => 1,
        ],[
            'borderRadius' => 5,
            'label' => 'Importe',
            'data' => [
                $results[0]['primera_semana_costoTotal'], 
                $results[0]['segunda_semana_costoTotal'], 
                $results[0]['tercera_semana_costoTotal'], 
                $results[0]['cuarta_semana_costoTotal']],
            'backgroundColor' => [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
            ],
            'borderColor' => [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
            ],
            'borderWidth' => 1,
        ],
    ],
];
echo json_encode([
    'ventas_anuales' => $dataAnual,
    'ventas_quincena' => $dataQuincenal,
    'ventas_semana' => $dataSemanal
]);
