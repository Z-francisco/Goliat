<?php 
include '../../debug/headers.php';
require_once '../../debug/global_variables.php';
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';

$mes_actual = date('m');

if (isset($_GET["ventas"])) {
    $ventas_contado = paternalia_query(0, "SELECT  MONTHNAME(fepe) AS mes, COUNT(*) AS total_clientes FROM  goliat_paternalia.clientes WHERE  YEAR(fepe) = 2024 GROUP BY  MONTH(fepe) ORDER BY  MONTH(fepe);");
    $meses_contado = implode(',', $ventas_contado['mes']);

    echo json_encode([
        "totalVentas" => paternalia_query(4, "SELECT id FROM clientes"),
        "ventasFinalizadas" => paternalia_query(4, "SELECT id FROM clientes_liquidados"),
        "ventasCanceladas" => paternalia_query(4, "SELECT id FROM clientes WHERE estatus = 3"),
        "ventasActivas" => paternalia_query(4, "SELECT id FROM clientes WHERE estatus = 1"),
        "ventasContado" => $meses_contado,
        "ventasContadoLiq" => paternalia_query(4, "SELECT id FROM clientes_liquidados WHERE formpago = 'Contado'"),
        "ventasCredito" => paternalia_query(4, "SELECT id FROM clientes WHERE formpago = 'Credito' and estatus = 1"),
        "ventasCreditoLiq" => paternalia_query(4, "SELECT id FROM clientes_liquidados WHERE formpago = 'Credito'"),
    ]);
}
if (isset($_GET["pagos"])) {
    echo json_encode([
        "totalPagos" => mysqli_num_rows(paternalia_query(1, "SELECT id FROM pagos")),
        "pagosMes" => mysqli_num_rows(paternalia_query(1, "SELECT id FROM pagos WHERE mes = $mes_actual")),
    ]);
}
if (isset($_GET["almacen"])) {
    echo json_encode([
        "elementosTotales" => mysqli_num_rows(paternalia_query(1, "SELECT clave_mat FROM almacen")),
    ]);
}


?>