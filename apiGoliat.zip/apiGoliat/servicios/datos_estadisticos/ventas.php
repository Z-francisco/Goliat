<?php 
include '../../debug/headers.php';
require_once '../../debug/global_variables.php';
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';

$anio = $_GET['anio'];

function obtenerAniosDisponibles() {
    $query = "SELECT DISTINCT YEAR(fepe) AS anio FROM clientes;";
    $result = paternalia_query(2, $query);
    $result = json_decode($result, true);

    $anios = array_column($result, 'anio');
    return $anios;
}

function obtenerDatosClientes($anio, $estatus, $xtrasql = '') {
    $query = "SELECT MONTH(fepe) AS mes, COUNT(id) AS cantidad_clientes
              FROM clientes
              WHERE YEAR(fepe) = $anio AND estatus = '$estatus' $xtrasql
              GROUP BY mes;";
    $result = paternalia_query(2, $query);
    $result = json_decode($result, true);

    $datosPorMes = array_fill(1, 12, 0); // Inicializar un array con ceros para todos los meses
    
    foreach ($result as $fila) {
        $mes = intval($fila['mes']);
        $cantidad = intval($fila['cantidad_clientes']);
        $datosPorMes[$mes] = $cantidad;
    }

    $datosOrdenados = array_values($datosPorMes); // Obtener los datos ordenados desde enero hasta diciembre

    return $datosOrdenados;
}

echo json_encode([
    "ventas" => obtenerDatosClientes($anio, 'negativo'), 
    "cancelaciones" => obtenerDatosClientes($anio, 'inactivo'),
    "liquidaciones" => obtenerDatosClientes($anio, 'negativo', 'and cantidadRestante <= 0'),
    "anios" => obtenerAniosDisponibles()
]);