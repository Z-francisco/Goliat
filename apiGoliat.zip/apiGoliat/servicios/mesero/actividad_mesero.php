<?php
include '../../debug/headers.php';
require_once '../../debug/global_variables.php';
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';
require_once '../security/global_functions.php';

//salir del programa si es que no esta logueada la ip
$ip = $_SERVER['REMOTE_ADDR'];
if (isLogued($ip) === 0) {
    exit();
    die;
}

$db_general = $GLOBALS["datos_generales"];
$data = json_decode(file_get_contents("php://input"), true);

//consulta un registro por medio de algun parametro
if (isset($_GET["mesasDisponibles"])) {
    echo paternalia_query(2, "SELECT *, id_mesa as id from goliat_restaurant.mesas m where m.estatus = 1");

    exit();
}