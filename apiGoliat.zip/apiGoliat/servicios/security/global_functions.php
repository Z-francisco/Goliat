<?php

// Encripta datos sensibles como por ejemplo direcciones, numeros telefonicos, correos, preguntas de seguridad, menos contraseñas, razon no seguro para este ambito
// Argumentos requiere el string a encriptar y el id de la persona
function encryptData($string_data, $publiKey, $privatKey)
{
    // Genera un par de claves pública y privada
    $resource = openssl_pkey_new(array(
        "private_key_bits" => 2048,  // Tamaño de la clave privada en bits
        "private_key_type" => OPENSSL_KEYTYPE_RSA  // Tipo de clave: RSA
    ));

    // Obtiene la clave pública
    openssl_pkey_export($resource, $privateKey);

    // Obtén la clave pública a partir de la clave privada
    $details = openssl_pkey_get_details($resource);
    $publicKey = $details["key"];

    if ($publiKey != '' && $privatKey != '') {
        $publicKey = $publiKey;
        $privateKey = $privatKey;
    }

    // Cifra los datos utilizando la clave pública
    openssl_public_encrypt($string_data, $encryptedData, $publicKey);

    return array('mensaje_cifrado' => base64_encode($encryptedData), 'private_key' => $privateKey, 'public_key' => $publicKey);

}
function decryptData($encryptedData, $privateKey){
    $datosCifradosAlmacenados = base64_decode($encryptedData);
    openssl_private_decrypt($datosCifradosAlmacenados, $decryptedData, $privateKey);
}
function isLogued($ip)
{
    $db_general = 'paternal_login';
    if (paternalia_query(4, "SELECT id from $db_general.logueados WHERE ip = '$ip'") > 0) {
        return 1;
    } else {
        return 0;
    }
}
function signOut($ip)
{
    $db_general = 'paternal_login';
    if (paternalia_query(1, "DELETE FROM $db_general.logueados WHERE ip = '$ip'") === true) {
        return array('respuesta' => 'Has cerrado sesión correctamente', 'tipo' => 'success');
    } else {
        return array('respuesta' => 'Ha ocurrido un error, no se cerro sesión', 'tipo' => 'error');
    }
}
/* 
$string_data = "Esto es un mensaje secreto";
echo encryptData($string_data); */