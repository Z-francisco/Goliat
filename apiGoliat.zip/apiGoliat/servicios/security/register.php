<?php
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/headers.php';
require_once './global_functions.php';

$data = json_decode(file_get_contents("php://input"), true);
extract($data);
if ($user_name != '' && $user_pass != '') {
    
$sal = bin2hex(random_bytes(16)); // Genera una sal aleatoria

$contraseña_con_salt = $user_pass . $sal;

$hash = password_hash($contraseña_con_salt, PASSWORD_BCRYPT);

//se manda la primera peticion de encriptacion de datos ya que al no mandar public key o no mandar private key genera una de cada una, misma que la funcion devuelve, de esta manera evitamos estar usando demasiadas keys
$security_quest = encryptData($recovery_question, '', '');
$privatKey = $security_quest['private_key'];
$publiKey = $security_quest['public_key'];
$security_res = encryptData($recovery_ask, $publiKey, $privatKey);
$recovery_ph = encryptData($recovery_phone, $publiKey, $privatKey);
$recovery_ma = encryptData($recovery_mail, $publiKey, $privatKey);

$secuquest = $security_quest['mensaje_cifrado'];
$secures = $security_res['mensaje_cifrado'];
$recophone = $recovery_ph['mensaje_cifrado'];
$recomail = $recovery_ma['mensaje_cifrado'];

$anti_dupe = paternalia_query(3, "SELECT user_id FROM goliat.users_passwords WHERE user_name = '$user_name'");
if ($anti_dupe['user_id'] > 0) {
    echo 'El usuario duplicadoo';
    die;
    exit();
}

paternalia_query(1, "INSERT INTO goliat.users_passwords(user_name, password) VALUES ('$user_name', '$hash')");
$give_user_id = paternalia_query(3, "SELECT user_id FROM goliat.users_passwords WHERE user_name = '$user_name'");
$id_usuario = $give_user_id['user_id'];
paternalia_query(1, "INSERT INTO goliat.cat_password_parameters(user_id, real_password) VALUES ($id_usuario, '$sal')");
paternalia_query(1, "INSERT INTO goliat.data_users_keys(user_id, private_key, public_key) VALUES ('$id_usuario', '$privatKey', '$publiKey')");
if (paternalia_query(1, "INSERT INTO goliat.users_data(user_id, name, first_last_name, second_last_name, security_question, security_response, recovery_phone, recovery_email) VALUES ($id_usuario, '$names', '$second_name', '$third_name', '$secuquest', '$secures', '$recophone', '$recomail')")) {
    echo json_encode(['respuesta' => 'Registro exitoso', "tipo" => 'success']);
}else{
    echo json_encode(['respuesta' => 'Registro Fallido', "tipo" => 'error']);
}
}