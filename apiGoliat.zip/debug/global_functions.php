<?php
    function comparacion($elemento1, $elemento2, $comparador){
        switch ($comparador) {
            case 'mayor':
                return $elemento1 > $elemento2;
            case 'menor':
                return $elemento1 < $elemento2;
            case 'igual':
                return $elemento1 == $elemento2 ? 'liquidado' : 'Activo';
            default:
                return false;
        }
    }
    
    function generarFechasDePagos($fechaInicial, $numeroFechas) {
        $fechas = array();
        $fecha = new DateTime($fechaInicial);
        
        for ($i = 0; $i < $numeroFechas; $i++) {
            $fechas[] = $fecha->format('Y-m-d');
            
            if ($fecha->format('d') >= 1 && $fecha->format('d') <= 6 || $fecha->format('d') >= 18 && $fecha->format('d') <= 31) {
                $fecha->modify('15 days');
            } elseif ($fecha->format('d') >= 7 && $fecha->format('d') <= 17) {
                $fecha->modify('last day of this month');
                $fechas[] = $fecha->format('Y-m-d');
                $fecha->modify('15 days');
            } else {
                $fecha->modify('last day of next month');
                $fechas[] = $fecha->format('Y-m-d');
                $fecha->modify('15 days');
            }
        }
        
        return $fechas;
    }
?>