<?php

use JetBrains\PhpStorm\Internal\ReturnTypeContract;

include 'global_variables.php';
$connect = new mysqli($GLOBALS['host'] . $GLOBALS['port'], $GLOBALS['user'], $GLOBALS['password'], $GLOBALS['datos_generales']);

// Ejecuta una consulta de sql con parametro where
// Parametros de la funcion: 0 = arreglo, 1 = query, 2 = json_encode | Query sql
function paternalia_query($formato, $query)
{
    $connect = new mysqli($GLOBALS['host'] . $GLOBALS['port'], $GLOBALS['user'], $GLOBALS['password'], $GLOBALS['datos_generales']);
    $result = mysqli_query($connect, $query);

    if ($formato === 4) {
        $resultado = mysqli_num_rows($result);
        return $resultado;
    }
    if ($formato === 3) {
        $result = mysqli_query($connect, $query); // Ejecuta la consulta
        if (!$result) {
            echo "Error en la consulta: " . mysqli_error($connect); // Muestra el mensaje de error
        } else {
            $resultado = mysqli_fetch_array($result, MYSQLI_ASSOC);
            return $resultado;
        }
    }
    if ($formato === 1) {
        if ($result === false) {
            $error = mysqli_error($connect);
            echo json_encode(['respuesta' => $error.$query, "tipo" => 'error']);
            exit();
        }
        return $result;
    }
    if ($formato === 2) {
        if ($result !== false) {
            $resultado = mysqli_fetch_all($result, MYSQLI_ASSOC);
            sort($resultado);
            $result_json = json_encode($resultado);
            return $result_json;
        } else {
            return json_encode([]); // Retorna un arreglo vacío si no hay resultados
        }
    }
    if ($formato === 0) {
        $resultado = mysqli_fetch_all($result, MYSQLI_ASSOC);
        return $resultado;
    }
}

// evaluacion pagos sirve para tener los pagos en prorroga, los pagos puntuales y tardios, 
// util para vista del perfil del cliente, incluso para estadisticas esta planeado usarse area de pagos
function evaluacion_pagos($id)
{
    $arreglo_pagos = paternalia_query(0, "
        SELECT folioRelacionado, dia, mes, anio, fepe FROM " . $GLOBALS['datos_generales'] . ".pagos p
        JOIN " . $GLOBALS['datos_generales'] . ".clientes c on c.id = p.folioRelacionado
        where p.folioRelacionado = $id
    ");

    $fechas = array(); // Arreglo para almacenar las fechas

    foreach ($arreglo_pagos as $ap) {
        $fecha = $ap['anio'] . '-' . $ap['mes'] . '-' . $ap['dia'];
        $fechas[] = $fecha;
    }

    $pago_prorroga = 0;
    $pago_tardio = 0;
    $pago_puntual = 0;

    for ($i = 0; $i < count($fechas) - 1; $i++) {
        $fecha_actual = $fechas[$i];
        $fecha_siguiente = $fechas[$i + 1];

        $diferencia_en_segundos = strtotime($fecha_siguiente) - strtotime($fecha_actual);
        $diferencia_en_dias = $diferencia_en_segundos / (60 * 60 * 24);

        if ($diferencia_en_dias > 20) {
            $pago_tardio++;
        } elseif ($diferencia_en_dias > 17) {
            $pago_prorroga++;
        } else {
            $pago_puntual++;
        }
    }

    $consulta_cliente = paternalia_query(0, "SELECT cantidadRestante, estatus FROM " . $GLOBALS['datos_generales'] . ".clientes WHERE id = $id");
    $cantidad_restante = $consulta_cliente[0]['cantidadRestante'];
    $estatus = $consulta_cliente[0]['estatus'];

    $mensaje = "";

    if ($estatus == "inactivo") {
        $mensaje = "Esta cuenta está cancelada.";
    } elseif ($cantidad_restante == 0) {
        $mensaje = "Esta cuenta está liquidada";
    } else {
        $mensaje = "Esta cuenta está activa";
    }

    return [
        "prorroga" => $pago_prorroga,
        "puntuales" => $pago_puntual,
        "tardios" => $pago_tardio,
        "mensaje" => $mensaje
    ];
}

function consulta_pagos()
{
    $consulta_clientes = paternalia_query(0, "
        SELECT c.id, c.nombre, c.numero, c.direccion, c.estatus, c.cantidadRestante, MAX(CONCAT(p.anio, '-', p.mes, '-', p.dia)) AS ultimo_pago_fecha
        FROM " . $GLOBALS['datos_generales'] . ".clientes c
        LEFT JOIN " . $GLOBALS['datos_generales'] . ".pagos p ON c.id = p.folioRelacionado
        WHERE c.estatus <> 'inactivo' AND c.cantidadRestante <> 0
        GROUP BY c.id
    ");

    $pagos_justo_hoy = array();
    $pagos_prorroga = array();
    $pagos_vencidos = array();
    $pagos_proximamente = array();

    foreach ($consulta_clientes as $cliente) {
        $diferencia_dias = 0;
        if ($cliente['ultimo_pago_fecha'] !== null) {
            $fecha_actual = date('Y-m-d');
            $fecha_ultimo_pago = $cliente['ultimo_pago_fecha'];
            $diferencia_en_segundos = strtotime($fecha_actual) - strtotime($fecha_ultimo_pago);
            $diferencia_dias = $diferencia_en_segundos / (60 * 60 * 24);
        }

        $cliente_resultado = array(
            "id" => $cliente['id'],
            "nombre" => $cliente['nombre'],
            "numero" => $cliente['numero'],
            "direccion" => $cliente['direccion'],
            "estatus" => $cliente['estatus'],
            "cantidadRestante" => $cliente['cantidadRestante'],
            "diferencia_dias" => $diferencia_dias
        );

        if ($diferencia_dias >= 15 && $diferencia_dias <= 17) {
            $pagos_justo_hoy[] = $cliente_resultado;
        } elseif ($diferencia_dias > 17 && $diferencia_dias <= 20) {
            $pagos_prorroga[] = $cliente_resultado;
        } elseif ($diferencia_dias > 20) {
            $pagos_vencidos[] = $cliente_resultado;
        } elseif ($diferencia_dias > 10) {
            $pagos_proximamente[] = $cliente_resultado;
        }
    }

    // Contar el número de elementos en cada sección
    $num_pagos_justo_hoy = count($pagos_justo_hoy);
    $num_pagos_prorroga = count($pagos_prorroga);
    $num_pagos_vencidos = count($pagos_vencidos);
    $num_pagos_proximamente = count($pagos_proximamente);

    // Construir el arreglo final
    $resultados = array(
        "pagos_justo_hoy" => $pagos_justo_hoy,
        "pagos_prorroga" => $pagos_prorroga,
        "pagos_vencidos" => $pagos_vencidos,
        "pagos_proximamente" => $pagos_proximamente
    );

    // Imprimir los resultados en formato JSON
    return [
        "resultados" => $resultados,
        "num_pagos_justo_hoy" => $num_pagos_justo_hoy,
        "num_pagos_prorroga" => $num_pagos_prorroga,
        "num_pagos_vencidos" => $num_pagos_vencidos,
        "num_pagos_proximamente" => $num_pagos_proximamente
    ];
}
