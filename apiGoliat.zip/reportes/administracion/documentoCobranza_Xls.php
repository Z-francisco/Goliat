<?php
date_default_timezone_set('America/Mexico_City');
include '../../debug/headers.php';
require_once '../../debug/global_variables.php';
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';
require_once '../../vendor/autoload.php';
require_once '../../servicios/security/global_functions.php';
$ip = $_SERVER['REMOTE_ADDR'];
if (isLogued($ip) === 0) {
    exit();
    die;
}

$id_cobrador = $_GET['id'];


function num2alpha($n)
{
    for ($r = ""; $n >= 0; $n = intval($n / 26) - 1) {
        $r = chr($n % 26 + 0x41) . $r;
    }
    return $r;
}

function estilos($color_letra = '00000', $fondo = 'FFFFFF', $tamanio_letra = 12, $tipo_letra = 'Arial', $bordes = false, $align = 'left')
{
    $estilos = array(
        'font' => array(
            'name' => $tipo_letra,
            'size' => $tamanio_letra,
            'color' => array(
                'rgb' => $color_letra,
            ),
        ),
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array(
                'rgb' => $fondo,
            ),
        ),
        'alignment' => array(
            'horizontal' => $align,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
        ),
    );

    if ($bordes) {
        $estilos['borders'] = array(
            'allborders' => array(
                'style' => PHPExcel_Style_Border::BORDER_THIN,
            ),
        );
    }
    return $estilos;
}

$array_clientes = paternalia_query(0, "SELECT id, nombre, costoTotal, cantidadRestante FROM goliat_paternalia.clientes WHERE cobrador_asignado = $id_cobrador");
$array_datos_cobrador = paternalia_query(0, "SELECT nombre, primer_apellido, segundo_apellido, comision FROM goliat_paternalia.tr_cobradores WHERE cobrador_id = $id_cobrador");

$objPHPExcel = new PHPExcel();

$header_styles = estilos('000000', 'FFFFFF', 12, 'Calibri', true, 'center');
$header_styles_liq = estilos('000000', '88e884', 12, 'Calibri', true);
$header_styles_can = estilos('000000', 'e54949', 12, 'Calibri', true);
$content_styles = estilos('000000', 'FFFFFF', 12, 'Calibri', true, 'center');

$header_cobranza = estilos('000000', 'FFFFFF', 12, 'Calibri', true, 'center');

$objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($header_styles);
$objPHPExcel->getActiveSheet()->getStyle('A5:H5')->applyFromArray($header_cobranza);

$objPHPExcel->getActiveSheet()->getRowDimension(1)->setRowHeight(30);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('A')->setWidth(5.45);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('B')->setWidth(9);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('C')->setWidth(35);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('D')->setWidth(13);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('E')->setWidth(13);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('F')->setWidth(13);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('G')->setWidth(13);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('H')->setWidth(23);
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A1:H1');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('D2:E2');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F2:G2');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F3:G3');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('D3:E3');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('D4:E4');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A2:C4');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('F4:G4');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('H2:H4');

$style = array(
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'vertical' => 'center',
    )
);

$objPHPExcel->getActiveSheet()->getStyle('H2:H4')->applyFromArray($style);

$gdImage = imagecreatefromjpeg('http://192.168.100.127/apiGoliat/assets/image/logo.jpg');

$fecha = date("d m Y");

$objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
$objDrawing->setName('Sample image');
$objDrawing->setDescription('Sample image');
$objDrawing->setImageResource($gdImage);
$objDrawing->setOffsetX(120);
$objDrawing->setOffsetY(5);
$objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
$objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
$objDrawing->setCoordinates('A2');
$objDrawing->setHeight(40);
$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());

$objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A1', 'RELACIÓN DE CUENTAS')
    ->setCellValue('D2', 'Gestor de cobranza')
    ->setCellValue('D3', 'Fecha')
    ->setCellValue('F3', $fecha)
    ->setCellValue('D4', 'Paternalia:')
    ->setCellValue('F4', 'Lic. Joseph Jonathan Zamora')
    ->setCellValue('A5', 'NO.')
    ->setCellValue('B5', 'CUENTA')
    ->setCellValue('C5', 'SUSCRIPTOR')
    ->setCellValue('D5', 'TOTAL')
    ->setCellValue('E5', 'FECHA')
    ->setCellValue('F5', 'IMPORTE')
    ->setCellValue('G5', 'SALDO')
    ->setCellValue('H5', 'OBSERVACIONES')
    ->setCellValue('H2', "ZONA $id_cobrador")
    ->setCellValue('F2', $array_datos_cobrador[0]['nombre'] . ' ' . $array_datos_cobrador[0]['primer_apellido'] . ' ' . $array_datos_cobrador[0]['segundo_apellido']);

$index = 0;
$fila_inicial = 6;
foreach ($array_clientes as $key) {
    $index++;
    $objPHPExcel->setActiveSheetIndex(0)
        ->setCellValue('A' . $fila_inicial, $index)
        ->setCellValue('B' . $fila_inicial, 'T-' . $key['id'])
        ->setCellValue('C' . $fila_inicial, $key['nombre'])
        ->setCellValue('D' . $fila_inicial, $key['costoTotal'])
        ->setCellValue('G' . $fila_inicial, $key['cantidadRestante']);
    $fila_inicial++;
}

$objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A' . ($fila_inicial + 1), $array_datos_cobrador[0]['nombre'] . ' ' . $array_datos_cobrador[0]['primer_apellido'] . ' ' . $array_datos_cobrador[0]['segundo_apellido'])
    ->setCellValue('A' . ($fila_inicial + 2), '_________________________________________________');
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A' . ($fila_inicial + 1) . ':' . 'H' . ($fila_inicial + 1));
$objPHPExcel->setActiveSheetIndex(0)->mergeCells('A' . ($fila_inicial + 2) . ':' . 'H' . ($fila_inicial + 2));
$objPHPExcel->getActiveSheet()->getStyle('A' . ($fila_inicial + 1) . ':' . 'H' . ($fila_inicial + 2))->applyFromArray($style);

$objPHPExcel->getActiveSheet()->getStyle('A6:H' . ($fila_inicial - 1))->applyFromArray($content_styles);


$objPHPExcel->setActiveSheetIndex(0);
$objPHPExcel->getActiveSheet()->setTitle('Entrega de cartera');

//hoja 2, liquidaciones

$hoja2 = $objPHPExcel->createSheet(null, 1);

$hoja2->setTitle('Cobranza');

$hoja2->getStyle('A1:F1')->applyFromArray($header_styles);
$hoja2->getStyle('A5:H5')->applyFromArray($header_cobranza);

$hoja2->getRowDimension(1)->setRowHeight(30);
$hoja2->getColumnDimension('A')->setWidth(5.45);
$hoja2->getColumnDimension('B')->setWidth(9);
$hoja2->getColumnDimension('C')->setWidth(35);
$hoja2->getColumnDimension('D')->setWidth(13);
$hoja2->getColumnDimension('E')->setWidth(13);
$hoja2->getColumnDimension('F')->setWidth(13);
$hoja2->getColumnDimension('G')->setWidth(13);
$hoja2->getColumnDimension('H')->setWidth(23);
$hoja2->mergeCells('A1:H1');
$hoja2->mergeCells('D2:E2');
$hoja2->mergeCells('F2:G2');
$hoja2->mergeCells('F3:G3');
$hoja2->mergeCells('D3:E3');
$hoja2->mergeCells('D4:E4');
$hoja2->mergeCells('A2:C4');
$hoja2->mergeCells('F4:G4');
$hoja2->mergeCells('H2:H4');

$style = array(
    'alignment' => array(
        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
        'vertical' => 'center',
    )
);

$hoja2->getStyle('H2:H4')->applyFromArray($style);

$gdImage = imagecreatefromjpeg('http://192.168.100.127/apiGoliat/assets/image/logo.jpg');

$fecha = date("d m Y");

$objDrawing = new PHPExcel_Worksheet_MemoryDrawing();
$objDrawing->setName('Sample image');
$objDrawing->setDescription('Sample image');
$objDrawing->setImageResource($gdImage);
$objDrawing->setOffsetX(120);
$objDrawing->setOffsetY(5);
$objDrawing->setRenderingFunction(PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
$objDrawing->setMimeType(PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
$objDrawing->setCoordinates('A2');
$objDrawing->setHeight(40);
$objDrawing->setWorksheet($hoja2);

$hoja2
    ->setCellValue('A1', 'RELACIÓN DE CUENTAS')
    ->setCellValue('D2', 'Gestor de cobranza')
    ->setCellValue('D3', 'Fecha')
    ->setCellValue('F3', $fecha)
    ->setCellValue('D4', 'Paternalia:')
    ->setCellValue('F4', 'Lic. Joseph Jonathan Zamora')
    ->setCellValue('A5', 'NO.')
    ->setCellValue('B5', 'CUENTA')
    ->setCellValue('C5', 'SUSCRIPTOR')
    ->setCellValue('D5', 'TOTAL')
    ->setCellValue('E5', 'FECHA')
    ->setCellValue('F5', 'IMPORTE')
    ->setCellValue('G5', 'SALDO')
    ->setCellValue('H5', 'OBSERVACIONES')
    ->setCellValue('H2', "ZONA $id_cobrador")
    ->setCellValue('F2', $array_datos_cobrador[0]['nombre'] . ' ' . $array_datos_cobrador[0]['primer_apellido'] . ' ' . $array_datos_cobrador[0]['segundo_apellido']);

$index = 0;
$fila_inicial = 6;
foreach ($array_clientes as $key) {
    $index++;
    $hoja2
        ->setCellValue('A' . $fila_inicial, $index)
        ->setCellValue('B' . $fila_inicial, 'T-' . $key['id'])
        ->setCellValue('C' . $fila_inicial, $key['nombre'])
        ->setCellValue('D' . $fila_inicial, $key['costoTotal']);
    $fila_inicial++;
}

$hoja2
    ->setCellValue('A' . ($fila_inicial + 1), $array_datos_cobrador[0]['nombre'] . ' ' . $array_datos_cobrador[0]['primer_apellido'] . ' ' . $array_datos_cobrador[0]['segundo_apellido'])
    ->setCellValue('A' . ($fila_inicial + 2), '_________________________________________________');

$hoja2->mergeCells('A' . ($fila_inicial + 1) . ':' . 'H' . ($fila_inicial + 1));
$hoja2->mergeCells('A' . ($fila_inicial + 2) . ':' . 'H' . ($fila_inicial + 2));
$hoja2->getStyle('A' . ($fila_inicial + 1) . ':' . 'H' . ($fila_inicial + 2))->applyFromArray($style);

$hoja2
    ->setCellValue('A' . ($fila_inicial + 3), 'Gestor de cobranza')
    ->setCellValue('A' . ($fila_inicial + 5), 'Lic. Joseph Jonathan Zamora Calderon')
    ->setCellValue('A' . ($fila_inicial + 7), 'Tesoreria y cobranza')
    ->setCellValue('A' . ($fila_inicial + 6), '_________________________________________________')
    ->setCellValue('A' . ($fila_inicial + 9), 'Somos el resultado de lo que hacemos repetidamente. La EXCELENCIA entonces no es un acto, si no un HÁBITO.')
    ->setCellValue('A' . ($fila_inicial + 10), '¡El secreto del ÉXITO es la PERSISTENCIA por la META!');

$hoja2->mergeCells('A' . ($fila_inicial + 2) . ':' . 'H' . ($fila_inicial + 2));
$hoja2->mergeCells('A' . ($fila_inicial + 3) . ':' . 'H' . ($fila_inicial + 3));
$hoja2->mergeCells('A' . ($fila_inicial + 4) . ':' . 'H' . ($fila_inicial + 4));
$hoja2->mergeCells('A' . ($fila_inicial + 5) . ':' . 'H' . ($fila_inicial + 5));
$hoja2->mergeCells('A' . ($fila_inicial + 7) . ':' . 'H' . ($fila_inicial + 7));
$hoja2->mergeCells('A' . ($fila_inicial + 6) . ':' . 'H' . ($fila_inicial + 6));
$hoja2->mergeCells('A' . ($fila_inicial + 9) . ':' . 'H' . ($fila_inicial + 9));
$hoja2->mergeCells('A' . ($fila_inicial + 10) . ':' . 'H' . ($fila_inicial + 10));

$hoja2->getStyle('A' . ($fila_inicial + 3) . ':' . 'H' . ($fila_inicial + 10))->applyFromArray($style);

$hoja2->getStyle('A6:H' . ($fila_inicial - 1))->applyFromArray($content_styles);



// Crea el objeto Writer para Excel 2007
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

// Establece las cabeceras para descargar el archivo
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Reporte General.xlsx"');
header('Cache-Control: max-age=0');

// Descarga el archivo
$objWriter->save('php://output');
exit;
