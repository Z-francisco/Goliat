<?php
date_default_timezone_set('America/Mexico_City');
include '../../debug/headers.php';
require_once '../../debug/global_variables.php';
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';
require_once '../../vendor/autoload.php';
require_once '../../servicios/security/global_functions.php';
$ip = $_SERVER['REMOTE_ADDR'];
if (isLogued($ip) === 0) {
    exit();
    die;
}


function num2alpha($n)
{
    for ($r = ""; $n >= 0; $n = intval($n / 26) - 1) {
        $r = chr($n % 26 + 0x41) . $r;
    }
    return $r;
}

function estilos($color_letra = '00000', $fondo = 'FFFFFF', $tamanio_letra = 12, $tipo_letra = 'Arial', $bordes = false)
{
    $estilos = array(
        'font' => array(
            'name' => $tipo_letra,
            'size' => $tamanio_letra,
            'color' => array(
                'rgb' => $color_letra,
            ),
        ),
        'fill' => array(
            'type' => PHPExcel_Style_Fill::FILL_SOLID,
            'color' => array(
                'rgb' => $fondo,
            ),
        ),
        'alignment' => array(
            'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
            'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER,
        ),
    );

    if ($bordes) {
        $estilos['borders'] = array(
            'allborders' => array(
                'style' => PHPExcel_Style_Border::BORDER_THIN,
            ),
        );
    }
    return $estilos;
}

$query_clientes = paternalia_query(1, "SELECT id, nombre, cantidadRestante, material, fepe FROM goliat_paternalia.clientes where estatus = 1 and cantidadRestante>0");
$query_clientes_liq = paternalia_query(1, "SELECT id, nombre, cantidadRestante, material, fepe FROM goliat_paternalia.clientes_liquidados");
$query_clientes_can = paternalia_query(1, "SELECT id, nombre, cantidadRestante, material, fepe FROM goliat_paternalia.clientes where estatus = 3");

$objPHPExcel = new PHPExcel();

$header_styles = estilos('000000', '0099da', 12, 'Calibri', true);
$header_styles_liq = estilos('000000', '88e884', 12, 'Calibri', true);
$header_styles_can = estilos('000000', 'e54949', 12, 'Calibri', true);
$content_styles = estilos('000000', 'FFFFFF', 12, 'Calibri', true);

$objPHPExcel->getActiveSheet()->getStyle('A1:F1')->applyFromArray($header_styles);
$objPHPExcel->getActiveSheet()->getRowDimension(1)->setRowHeight(30);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('A')->setWidth(5.45);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('B')->setWidth(35);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('D')->setWidth(13);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('E')->setWidth(13);
$objPHPExcel->setActiveSheetIndex()->getColumnDimension('F')->setWidth(13);

$objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('A1', 'Folio')
    ->setCellValue('B1', 'Nombre completo')
    ->setCellValue('C1', 'Restante')
    ->setCellValue('D1', 'No. de pagos')
    ->setCellValue('E1', 'Materiales')
    ->setCellValue('F1', 'Fecha');

$fila_inicial = 2;
$inicio_contenido = 2;

// Obtener todos los registros en un arreglo
$arreglo_clientes = mysqli_fetch_all($query_clientes, MYSQLI_ASSOC);

// Ordenar el arreglo por la fecha
usort($arreglo_clientes, function ($a, $b) {
    return strtotime($a['fepe']) - strtotime($b['fepe']);
});

$objPHPExcel->setActiveSheetIndex(0)
    ->setCellValue('H1', mysqli_num_rows($query_clientes))
    ->setCellValue('G1', 'Total:');

// Iterar sobre el arreglo ordenado
foreach ($arreglo_clientes as $arreglo_clientes_item) {
    $query_pagos = paternalia_query(1, "SELECT id FROM goliat_paternalia.pagos WHERE folioRelacionado=" . $arreglo_clientes_item['id']);
    $objPHPExcel->setActiveSheetIndex(0)
        ->setCellValue('A' . $fila_inicial, 'T-' . $arreglo_clientes_item['id'])
        ->setCellValue('B' . $fila_inicial, $arreglo_clientes_item['nombre'])
        ->setCellValue('C' . $fila_inicial, $arreglo_clientes_item['cantidadRestante'])
        ->setCellValue('D' . $fila_inicial, mysqli_num_rows($query_pagos))
        ->setCellValue('E' . $fila_inicial, $arreglo_clientes_item['material'])
        ->setCellValue('F' . $fila_inicial, $arreglo_clientes_item['fepe']);
    $fila_inicial++;
}

$objPHPExcel->getActiveSheet()->getStyle('A' . $inicio_contenido . ':F' . ($fila_inicial - 1))->applyFromArray($content_styles);

$objPHPExcel->getActiveSheet()->getStyle('G1:H1')->applyFromArray($content_styles);

$fila_inicial = 2;

$objPHPExcel->getActiveSheet()->setTitle('Ventas activas');

//hoja 2, liquidaciones

$hoja2 = $objPHPExcel->createSheet(null, 1);

$hoja2->setTitle('Ventas liquidadas');
$hoja2->getStyle('A1:F1')->applyFromArray($header_styles_liq);
$hoja2->getRowDimension(1)->setRowHeight(30);
$hoja2->getColumnDimension('A')->setWidth(5.38);
$hoja2->getColumnDimension('B')->setWidth(35);
$hoja2->getColumnDimension('D')->setWidth(13);
$hoja2->getColumnDimension('E')->setWidth(13);
$hoja2->getColumnDimension('F')->setWidth(13);

$arreglo_clientes_liq = mysqli_fetch_all($query_clientes_liq, MYSQLI_ASSOC);

$hoja2->setCellValue('A1', 'Folio')
    ->setCellValue('B1', 'Nombre completo')
    ->setCellValue('C1', 'Restante')
    ->setCellValue('D1', 'No. de pagos')
    ->setCellValue('E1', 'Materiales')
    ->setCellValue('F1', 'Fecha');;

// Ordenar el arreglo por la fecha
usort($arreglo_clientes_liq, function ($a, $b) {
    return strtotime($a['fepe']) - strtotime($b['fepe']);
});

$hoja2->setCellValue('H1', mysqli_num_rows($query_clientes_liq))
    ->setCellValue('G1', 'Total:');

// Iterar sobre el arreglo ordenado
foreach ($arreglo_clientes_liq as $arreglo_clientes_item) {
    $query_pagos = paternalia_query(1, "SELECT id FROM goliat_paternalia.pagos WHERE folioRelacionado=" . $arreglo_clientes_item['id']);
    $hoja2->setCellValue('A' . $fila_inicial, 'T-' . $arreglo_clientes_item['id'])
        ->setCellValue('B' . $fila_inicial, $arreglo_clientes_item['nombre'])
        ->setCellValue('C' . $fila_inicial, $arreglo_clientes_item['cantidadRestante'])
        ->setCellValue('D' . $fila_inicial, mysqli_num_rows($query_pagos))
        ->setCellValue('E' . $fila_inicial, $arreglo_clientes_item['material'])
        ->setCellValue('F' . $fila_inicial, $arreglo_clientes_item['fepe']);
    $fila_inicial++;
}

$hoja2->getStyle('A' . $inicio_contenido . ':F' . ($fila_inicial - 1))->applyFromArray($content_styles);

$hoja2->getStyle('G1:H1')->applyFromArray($content_styles);

$fila_inicial = 2;

//Hoja 3, cancelaciones

$hoja3 = $objPHPExcel->createSheet(null, 1);

$hoja3->setTitle('Ventas canceladas');
$hoja3->getStyle('A1:F1')->applyFromArray($header_styles_can);
$hoja3->getRowDimension(1)->setRowHeight(30);
$hoja3->getColumnDimension('A')->setWidth(5.38);
$hoja3->getColumnDimension('B')->setWidth(35);
$hoja3->getColumnDimension('D')->setWidth(13);
$hoja3->getColumnDimension('E')->setWidth(13);
$hoja3->getColumnDimension('F')->setWidth(13);

$arreglo_clientes_can = mysqli_fetch_all($query_clientes_can, MYSQLI_ASSOC);

$hoja3->setCellValue('A1', 'Folio')
    ->setCellValue('B1', 'Nombre completo')
    ->setCellValue('C1', 'Restante')
    ->setCellValue('D1', 'No. de pagos')
    ->setCellValue('E1', 'Materiales')
    ->setCellValue('F1', 'Fecha');;

usort($arreglo_clientes_can, function ($a, $b) {
    return strtotime($a['fepe']) - strtotime($b['fepe']);
});

$hoja3->setCellValue('H1', mysqli_num_rows($query_clientes_can))
    ->setCellValue('G1', 'Total:');

// Iterar sobre el arreglo ordenado
foreach ($arreglo_clientes_can as $arreglo_clientes_item) {
    $query_pagos = paternalia_query(1, "SELECT id FROM goliat_paternalia.pagos WHERE folioRelacionado=" . $arreglo_clientes_item['id']);
    $hoja3->setCellValue('A' . $fila_inicial, 'T-' . $arreglo_clientes_item['id'])
        ->setCellValue('B' . $fila_inicial, $arreglo_clientes_item['nombre'])
        ->setCellValue('C' . $fila_inicial, $arreglo_clientes_item['cantidadRestante'])
        ->setCellValue('D' . $fila_inicial, mysqli_num_rows($query_pagos))
        ->setCellValue('E' . $fila_inicial, $arreglo_clientes_item['material'])
        ->setCellValue('F' . $fila_inicial, $arreglo_clientes_item['fepe']);
    $fila_inicial++;
}

$hoja3->getStyle('A' . $inicio_contenido . ':F' . ($fila_inicial - 1))->applyFromArray($content_styles);

$hoja3->getStyle('G1:H1')->applyFromArray($content_styles);

$objPHPExcel->setActiveSheetIndex(0);

// Crea el objeto Writer para Excel 2007
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

// Establece las cabeceras para descargar el archivo
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Reporte General.xlsx"');
header('Cache-Control: max-age=0');

// Descarga el archivo
$objWriter->save('php://output');
exit;
