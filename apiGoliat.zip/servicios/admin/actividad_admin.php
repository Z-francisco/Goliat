<?php
include '../../debug/headers.php';
require_once '../../debug/global_variables.php';
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/global_functions.php';
require_once '../security/global_functions.php';

//salir del programa si es que no esta logueada la ip
$ip = $_SERVER['REMOTE_ADDR'];
if (isLogued($ip) === 0) {
    exit();
    die;
}

$db_general = $GLOBALS["datos_generales"];
$data = json_decode(file_get_contents("php://input"), true);

//consulta un registro por medio de algun parametro
if (isset($_GET["crearMesa"])) {
    extract($data);
    $crearMesaQuery = paternalia_query(1, "INSERT INTO goliat_restaurant.mesas(num_asientos, ubicacion) VALUES('$num_asientos', '$ubicacion')");

    if ($crearMesaQuery == 1) {
        echo json_encode(['respuesta' => 'Creaste una mesa exitosamente', "tipo" => 'success']);
    }else{
        echo json_encode(['respuesta' => 'Ha ocurrido un error', "tipo" => 'error']);
    }

    exit();
}