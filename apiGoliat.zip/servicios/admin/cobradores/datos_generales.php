<?php
include '../../../debug/headers.php';
require_once '../../../debug/global_variables.php';
require_once '../../../debug/global_sql_functions.php';
require_once '../../../debug/global_functions.php';
require_once '../../security/global_functions.php';
/* 
// Si no está logueado se le manda a la goma con todo el respeto del mundo
$ip = $_SERVER['REMOTE_ADDR'];
if (isLogued($ip) === 0) {
    exit();
    die;
} */

$db_general = $GLOBALS["datos_generales"];
$data = json_decode(file_get_contents("php://input"), true);

if (isset($_GET["consultar"])) {
    $id = isset($data['id']) ? $data['id'] : $_GET["consultar"];
    echo paternalia_query(2, "SELECT * FROM $db_general.tr_cobradores WHERE cobrador_id = $id");
    exit();
}

if (isset($_GET["asignar_cuentas"])) {
    $ids = isset($data['asignar_cuentas']) ? $data['asignar_cuentas'] : $_GET["asignar_cuentas"];
    $cobrador = isset($data['cobrador']) ? $data['cobrador'] : $_GET["cobrador"];
    $cuentas_array = explode(',', $ids);
    foreach ($cuentas_array as $id) {
        echo json_encode (paternalia_query(3, "UPDATE $db_general.clientes SET cobrador_asignado = $cobrador WHERE id = $id"));
        echo json_encode (paternalia_query(3, "UPDATE $db_general.pedidos SET cobrador_asignado = $cobrador WHERE id = $id"));
    }
    exit();
}

if (isset($_GET["insertar"])) {
    extract($data);
    if ($nombre != '' && $numero_tel != '' && $rfc != '' && $comision != '') {
        $insercion = paternalia_query(1, 
        "INSERT INTO $db_general.tr_cobradores(nombre, primer_apellido, segundo_apellido, numero_tel, rfc, ref_bancaria, direccion, comision) 
        VALUES('$nombre', '$primer_apellido', '$segundo_apellido', '$numero_tel', '$rfc', '$ref_bancaria', '$direccion', '$comision')");
        if (!empty($insercion)) {
            echo json_encode(['respuesta' => 'Has registrado al nuevo vendedor con exito :)', "tipo" => 'success']);
        }else{
            echo json_encode(['respuesta' => 'Ha ocurrido un error, si el problema persiste contacte a soporte', "tipo" => 'error']);
        }
    }
    exit();
}
if (isset($_GET["modificar"])) {
    $id = isset($data['id']) ? $data['id'] : $_GET["modificar"];
    extract($data);

    if (paternalia_query(1, "UPDATE $db_general.tr_cobradores SET nombre='$nombre',primer_apellido='$primer_apellido',segundo_apellido='$segundo_apellido',numero_tel='$numero_tel',rfc='$rfc',ref_bancaria='$ref_bancaria',direccion='$direccion',comision='$comision' WHERE cobrador_id='$id'")) {
        echo json_encode(["respuesta" => 'Los datos han sido modificados con éxito', "tipo" => 'success']);
    }
    exit();
}

if (isset($_GET["ver_cuentas"])) {
    $id = $_GET["ver_cuentas"];
    if ($_GET["ver_cuentas"]) {
            $all_customers = paternalia_query(0, 
                "SELECT c.id, c.nombre, c.numero, c.cantidadRestante, c.costoTotal, cec.estatus_nombre as estatus, cec.estatus_color 
                FROM $db_general.clientes c 
                LEFT JOIN $db_general.cat_estatus_clientes cec 
                ON cec.id_estatus = c.estatus 
                WHERE c.cobrador_asignado = $id
                
                UNION
                
                SELECT cl.id, cl.nombre, cl.numero, cl.cantidadRestante, cl.costoTotal,  cec.estatus_nombre as estatus, cec.estatus_color 
                FROM $db_general.clientes_liquidados cl 
                LEFT JOIN $db_general.cat_estatus_clientes cec 
                ON cec.id_estatus = cl.estatus 
                WHERE cl.cobrador_asignado = $id;
                "
            );
            echo json_encode(["clientes" => $all_customers]);
    }
    exit();
}

if (isset($_GET["remover_cliente"])) {

    $id = isset($data['id']) ? $data['id'] : $_GET["remover_cliente"];

    if (paternalia_query(1, "UPDATE $db_general.clientes SET cobrador_asignado = '' WHERE id = $id") > 0) {
        echo json_encode(['respuesta' => 'Se ha removido la cuenta con exito', "tipo" => 'success']);
    }else{
        echo json_encode(['respuesta' => 'Ha ocurrido un error', "tipo" => 'error']);
    }
    exit();
}

if (isset($_GET["consulta"])) {
    if ($_GET["consulta"] == '020410') {
        echo paternalia_query(2, "SELECT cobrador_id, nombre, primer_apellido, segundo_apellido, numero_tel, direccion, situacion_id FROM $db_general.tr_cobradores WHERE estatus = 1");
    }
    exit();
}
