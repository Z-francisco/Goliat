<!DOCTYPE html>
<html id="particles-js">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/signin.css">
	<link rel="icon" href="../../assets/img/fondo.png">
	<title></title>
</head>

<body>

	<h1 id="acheuno" class="centrar">Vamonos, como de que no, ya termine todo :3</h1>
	<a href="../index.php"><button class="centrar btn-primary btn" id="btn4">Volver a la pagina principal</button></a>
	<iframe id="archivo" class="centrar" src="../archives/presentación.pdf" height="600px" width="90%"></iframe>

	<script src="../../assets/js/particles.js"></script>
	<script src="../../assets/js/app.js"></script>
</body>
</html>
<?php
	$conectar=@mysqli_connect('localhost','estudyco_certificados','certificadosEscuelas2022.@','estudyco_datosEscuelas');
	if (!$conectar) {
		echo "No se pudo conectar con el servidor";
	}else{
		echo "";
	}
	$email=$_POST['email'];
	$escuela=$_POST['escuela'];
	$numero=$_POST['numero'];
	$nombre=$_POST['nombre'];
	$fecha=$_POST['fecha'];

	$sql="INSERT INTO base VALUES('$email',
									  '$escuela',
									  '$numero',
									  '$nombre',
									  '$fecha')";

	$ejecutar=mysqli_query($conectar, $sql) or die(mysqli_error($conectar));
	if (!$ejecutar) {
		echo "Ha ocurrido un error al ejecutar";
	}else {
		echo "";
	}
?>

