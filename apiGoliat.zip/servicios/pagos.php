<?php
include '../debug/headers.php';
require_once '../debug/global_variables.php';
require_once '../debug/global_sql_functions.php';
require_once '../debug/global_functions.php';
require_once 'security/global_functions.php';
$ip = $_SERVER['REMOTE_ADDR'];
if (isLogued($ip) === 0) {
    exit();
    die;
}

$db_general = $GLOBALS["datos_generales"];
$data = json_decode(file_get_contents("php://input"));

if (isset($_GET["consultar"])) {
    $id = (isset($data->id)) ? $data->id : $_GET["consultar"];
    $consulta_general = paternalia_query(0, "SELECT * FROM " . $GLOBALS["datos_generales"] . ".pagos WHERE folioRelacionado = $id");

    function compararFechas($a, $b) {
        $fechaA = strtotime($a['anio'] . '-' . $a['mes'] . '-' . $a['dia']);
        $fechaB = strtotime($b['anio'] . '-' . $b['mes'] . '-' . $b['dia']);
        return $fechaA - $fechaB;
    }
    
    usort($consulta_general, 'compararFechas');

    $evaluacion = evaluacion_pagos($id); // Obtener la evaluación

    echo json_encode(["pagos" => $consulta_general, "evaluacion" => $evaluacion]);

    exit();
}

if (isset($_GET["borrar_pago"])) {
    $id = (isset($data->id)) ? $data->id : $_GET["borrar_pago"];
    
    if ($id != '') {
        $pago_a_eliminar = paternalia_query(3, "SELECT p.cantidad, p.folioRelacionado, c.cantidadRestante FROM $db_general.pagos p
                                            JOIN $db_general.clientes c on c.id = p.folioRelacionado
                                            WHERE p.id = $id");
    extract($pago_a_eliminar);
    $nueva_cantidad_restante = $cantidadRestante + $cantidad;
    paternalia_query(1, "UPDATE $db_general.clientes SET cantidadRestante = '$nueva_cantidad_restante' WHERE id = $folioRelacionado");
    paternalia_query(1, "DELETE FROM $db_general.pagos WHERE id = $id");
    }
    exit();
}
//consulta un registro por medio de algun parametro
if (isset($_GET["pago"])) {
    $id = (isset($data->id)) ? $data->id : $_GET["pago"];
    $cantidad = $data->cantidad;
    $fechaman = $data->fechaman;

    $partes = explode('-', $fechaman);
    $anio = $partes[0];
    $mes = $partes[1];
    $dia = $partes[2];

    $cantidad_restante_arreglo = paternalia_query(0, "SELECT cantidadRestante FROM $db_general.clientes where id = $id");
    $restante_a_pagar = $cantidad_restante_arreglo[0]["cantidadRestante"] - $cantidad;

    if (($id != "") && ($cantidad != "")) {
        paternalia_query(1, "INSERT INTO $db_general.pagos(folioRelacionado, cantidad, mes, dia, anio, concepto) VALUES ('$id','$cantidad', '$mes','$dia','$anio', 'Pago quincenal')");
        paternalia_query(1, "UPDATE $db_general.clientes SET cantidadRestante = '$restante_a_pagar' WHERE id = '$id'");
        
        if ($restante_a_pagar < 0.00001) {
            paternalia_query(1, "UPDATE $db_general.clientes SET estatus = '2' WHERE id = $id");
            if (paternalia_query(1, "INSERT INTO $db_general.clientes_liquidados SELECT * FROM $db_general.clientes WHERE id = $id")) {
                paternalia_query(1, "DELETE FROM $db_general.clientes WHERE id = $id");
                echo json_encode(["respuesta" => 'La cuenta se ha liquidado! HURRAA', "tipo" => 'success']);
            }else{
                echo json_encode(["respuesta" => 'Contacte a soporte', "tipo" => 'error']);
            }
        }else {
            echo json_encode(["respuesta" => 'Pago agregado con éxito', "tipo" => 'success']);
        }
    } else {
        echo json_encode(["respuesta" => 'Falta algún campo', "tipo" => 'error']);
    }
    exit();
}

/* if (isset($_GET['estadisticos'])) {
    $mes_actual = date('m');
    $cercanos_a_hoy = paternalia_query(0, "SELECT id, numerodequin FROM $db_general.clientes WHERE estatus = 'negativo' AND fepe IS NOT NULL");

    foreach ($cercanos_a_hoy as $cao) {
        $cliente = paternalia_query(3, "SELECT nombre FROM $db_general.clientes WHERE id = " . $cao['id']);
        $nombre_cliente = $cliente['nombre'];

        $primer_pago = paternalia_query(3, "SELECT dia, mes, anio FROM $db_general.pagos WHERE folioRelacionado = " . $cao['id']);

        if ($primer_pago['dia'] != '' && $primer_pago['anio'] != '') {
            if ($primer_pago['dia'] > 20) {
                $primer_pago_fecha = $primer_pago['anio'] . '-' . $primer_pago['mes'] . '-' . $primer_pago['dia'];
                $mes_actual_num = intval($mes_actual);
                $mes_faltante = '';
                $aportaciones_faltantes = array();

                // Verificar primer mes
                $mes_actual_num--;
                if ($primer_pago['mes'] != $mes_actual_num) {
                    $mes_faltante = $mes_actual_num;
                }

                // Verificar meses posteriores
                for ($i = $mes_actual_num; $i >= intval($primer_pago['mes']); $i--) {
                    $aportacion1_query = paternalia_query(1, "SELECT id FROM $db_general.pagos WHERE folioRelacionado = ".$cao['id']." AND mes = ".$i." AND (dia >= 15 OR dia <= 1)");
                    $aportacion2_query = paternalia_query(1, "SELECT id FROM $db_general.pagos WHERE folioRelacionado = ".$cao['id']." AND mes = ".$i." AND dia >= 15 AND dia <= 30");

                    $aportacion1 = mysqli_num_rows($aportacion1_query);
                    $aportacion2 = mysqli_num_rows($aportacion2_query);

                    if ($i == $mes_actual_num && $primer_pago['dia'] > 15) {
                        // Verificar aportación actual si el día del primer pago es mayor a 15
                        if ($aportacion1 < 1) {
                            $aportaciones_faltantes[] = $i;
                        }
                    } else {
                        // Verificar dos aportaciones en los demás meses
                        if ($aportacion1 < 1 || $aportacion2 < 1) {
                            $aportaciones_faltantes[] = $i;
                        }
                    }
                }

                if (!empty($aportaciones_faltantes)) {
                    echo "Faltan aportaciones en los siguientes meses para el cliente " . $nombre_cliente . ": ";
                    foreach ($aportaciones_faltantes as $mes_faltante) {
                        echo $mes_faltante . " ";
                    }
                    echo "\n";
                }

                if ($mes_faltante != '' && abs($mes_faltante - $mes_actual) <= 1) {
                    echo "La próxima aportación para el cliente " . $nombre_cliente . " está cerca del día actual.\n";
                }

                // Verificar si el cliente no debe nada
                $saldo_actual = paternalia_query(3, "SELECT saldo FROM $db_general.clientes WHERE id = " . $cao['id']);
                if ($saldo_actual['saldo'] == 0) {
                    echo "El cliente " . $nombre_cliente . " no debe nada.\n";
                }
        }
    }
} 

}
*/