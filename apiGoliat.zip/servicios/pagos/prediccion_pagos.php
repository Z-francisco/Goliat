<?php

require_once '../../debug/headers.php';

function generarFechasDePagos($fechaInicial, $numeroFechas) {
    $fechas = array();
    $fecha = new DateTime($fechaInicial);
    
    for ($i = 0; $i < $numeroFechas; $i++) {
        $fechas[] = $fecha->format('Y-m-d');
        
        if ($fecha->format('d') >= 1 && $fecha->format('d') <= 6 || $fecha->format('d') >= 18 && $fecha->format('d') <= 31) {
            $fecha->modify('15 days');
        } elseif ($fecha->format('d') >= 7 && $fecha->format('d') <= 17) {
            $fecha->modify('last day of this month');
            $fechas[] = $fecha->format('Y-m-d');
            $fecha->modify('15 days');
        } else {
            $fecha->modify('last day of next month');
            $fechas[] = $fecha->format('Y-m-d');
            $fecha->modify('15 days');
        }
    }
    
    return $fechas;
}

// Ejemplo de uso
$fechaInicial = '2024-01-07';
$numeroFechas = 5;
$fechasGeneradas = generarFechasDePagos($fechaInicial, $numeroFechas);

echo json_encode($fechasGeneradas);     


