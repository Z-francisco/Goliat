<?php
include '../debug/headers.php';
require_once '../debug/global_variables.php';
require_once '../debug/global_sql_functions.php';
require_once '../debug/global_functions.php';
require_once 'security/global_functions.php';
$ip = $_SERVER['REMOTE_ADDR'];
if (isLogued($ip) === 0) {
    exit();
    die;
}

$db_general = $GLOBALS["datos_generales"];
$data = json_decode(file_get_contents("php://input"), true);

//consulta un registro por medio de algun parametro
if (isset($_GET["consultar"])) {
    $pedido = paternalia_query(0, "SELECT * FROM $db_general.pedidos WHERE id = " . $_GET["consultar"]);
    // Transformar el campo "material" en un array de objetos
    $material = explode(',', $pedido[0]['material']);
    $materialArray = [];

    foreach ($material as $item) {
        // Consultar los datos del material desde $db_general.almacen usando la clave_mat
        $materialData = paternalia_query(3, "SELECT clave_mat, nombre_mat FROM $db_general.almacen WHERE clave_mat = $item");
        if ($materialData) {
            $materialArray[] = $materialData;
        }
    }

    // Reemplazar el campo "material" con el nuevo array de objetos
    $pedido[0]['material'] = $materialArray;

    // Devolver los datos transformados en formato JSON
    echo json_encode($pedido);
    exit();
}
if (isset($_GET["actualizar"])) {

    $id = isset($data['id']) ? $data['id'] : $_GET["actualizar"];
    extract($data);

    $material_en_texto = implode(',', array_column($material, 'clave_mat'));

    if (paternalia_query(1, "UPDATE $db_general.pedidos SET nombre='$nombre',numero='$numero',direccion='$direccion',municipio='$municipio',costoTotal='$costoTotal',lapsodedias='$lapsodedias',numerodequin='$numerodequin', material = '$material_en_texto' WHERE id='$id'")) {
        echo json_encode(["respuesta" => 'Los datos han sido modificados con éxito', "tipo" => 'success']);
    }
    exit();
}
if (isset($_GET["insertar"])) {
    extract($data);

    if ($nombre != '' && $numero != '') {
        $siExiste_en_clientes = paternalia_query(3, "SELECT id FROM $db_general.clientes WHERE numero = $numero OR nombre = '$nombre'");
        $siExiste_en_pedidos = paternalia_query(3, "SELECT id FROM $db_general.pedidos WHERE numero = $numero OR nombre = '$nombre'");

        if ($siExiste_en_clientes['id'] > 0) {
            echo json_encode(["respuesta" => 'Hay un registro con datos similares de folio T-' . $siExiste_en_clientes['id'] . ' en la sección de clientes', "tipo" => 'error']);
            die;
            exit();
        }
        if ($siExiste_en_pedidos['id'] > 0) {
            echo json_encode(["respuesta" => 'Hay un registro con datos similares de folio T-' . $siExiste_en_pedidos['id'] . ' en la sección de pedidos', "tipo" => 'error']);
            die;
            exit();
        }
    }

    if ($nombre == '' || $material == [] || $numero == '') {
        echo json_encode(["respuesta" => 'Falta ingresar nombre, material o número', "tipo" => 'warning']);
        die;
        exit();
    }

    if ($siExiste_en_clientes['id'] > 0) {
        echo json_encode(["respuesta" => 'Hay un registro con datos similares de folio T-' . $siExiste_en_clientes['id'] . ' en la sección de clientes', "tipo" => 'error']);
        die;
        exit();
    }
    if ($siExiste_en_pedidos['id'] > 0) {
        echo json_encode(["respuesta" => 'Hay un registro con datos similares de folio T-' . $siExiste_en_pedidos['id'] . ' en la sección de pedidos', "tipo" => 'error']);
        die;
        exit();
    }

    $material_en_texto = implode(',', array_column($material, 'clave_mat'));

    // Verificando que los materiales tengan existencia antes de iniciar todo proceso, si algun elemento carece de existencias solo detendra el proceso, no afectara la DB
    foreach (array_column($material, 'clave_mat') as $item) {
        $almacen_arreglo = paternalia_query(3, "SELECT cantidad_mat FROM $db_general.almacen WHERE clave_mat = $item");
        $cantidad_mat_existente = $almacen_arreglo["cantidad_mat"] - 1;
        if ($cantidad_mat_existente < 0) {
            echo json_encode(["respuesta" => 'Falta material para hacer el pedido', "tipo" => 'error']);
            exit();
        }
    }

    if (($nombre != "")) {
        if (paternalia_query(1, "INSERT INTO $db_general.pedidos(nombre, numero, direccion, municipio, costoTotal, lapsodedias, numerodequin, material, fepe) VALUES('$nombre', '$numero', '$direccion', '$municipio', '$costoTotal', '$lapsodedias', '$numerodequin', '$material_en_texto', '$fechaman')")) {
            echo json_encode(["respuesta" => 'Has ingresado un nuevo pedido con éxito', "tipo" => 'success']);
            // Descuenta el elento de almacen y lo asigna a elementos en apartado de pedidos
            foreach (array_column($material, 'clave_mat') as $item) {
                $almacen_arreglo = paternalia_query(0, "SELECT cantidad_mat, en_pedido FROM $db_general.almacen WHERE clave_mat = '$item'");
                $cantidad_mat_existente = $almacen_arreglo[0]["cantidad_mat"] - 1;
                $en_pedido_existente = $almacen_arreglo[0]["en_pedido"] + 1;
                paternalia_query(1, "UPDATE $db_general.almacen SET cantidad_mat = '$cantidad_mat_existente', en_pedido = '$en_pedido_existente' WHERE clave_mat = '$item'");
            }
        } else {
            echo json_encode(["respuesta" => 'Ha ocurrido un error', "tipo" => 'error']);
        }
    }
    exit();
}
if (isset($_GET["verificar"])) {

    $id = isset($data['id']) ? $data['id'] : $_GET["verificar"];
    extract($data);

    $material_en_texto = implode(',', array_column($material, 'clave_mat'));

    if ($nombre != '') {
        $siExiste = paternalia_query(3, "SELECT id FROM $db_general.pedidos WHERE id = $id");

        if ($siExiste['id'] > 0) {
            # code...
        } else {
            echo json_encode(["respuesta" => 'Este pedido ya es venta', "tipo" => 'error']);
            die;
            exit();
        }

        $restante = $costoTotal - $aportacionInicial;
        $quincena = $restante / $numerodequin;

        // la variable success, se actualiza conforme pase los condicionales, util para front
        $success = 'error';

        // Verificando que los materiales tengan existencia en pedido antes de iniciar todo proceso, si algun elemento carece de existencias solo detendra el proceso, no afectara la DB
        foreach (array_column($material, 'clave_mat') as $item) {
            $almacen_arreglo = paternalia_query(3, "SELECT en_pedido, en_venta FROM $db_general.almacen WHERE clave_mat = '$item'");
            $cantidad_mat_existente = $almacen_arreglo["en_pedido"] - 1;
            if ($cantidad_mat_existente < 0) {
                echo json_encode(["respuesta" => 'Te faltan elementos en almacen para vericar la venta', "tipo" => 'error']);
                die;
            }
        }

        $parte = explode('-', $fechaman);

        $aniofechaman = $parte[0];
        $mesfechaman = $parte[1];
        $diafechaman = $parte[2];

        $fecha_pedido = paternalia_query(3, "SELECT fepe FROM $db_general.pedidos where id = $id");
        $fepe = $fecha_pedido['fepe'];

        if (($nombre != "")) {
            if (paternalia_query(1, "INSERT INTO $db_general.clientes(id, nombre ,numero ,direccion ,municipio ,costoTotal, cantidadRestante ,aportacionInicial, formpago ,material ,lapsodedias, numerodequin, quincena, clientejob, nombreesposo, esposojob, esposonro, ninonmb, ninogg, escuelanino, rf1nmb, rf1direcc, rf1nro, rf1parent, estatus, fepe) VALUES('$id','$nombre','$numero','$direccion','$municipio','$costoTotal','$restante','$aportacionInicial', '$formpago', '$material_en_texto','$lapsodedias', '$numerodequin', '$quincena', '$clientejob', '$nombreesposo', '$esposojob', '$esposonro', '$ninonmb', '$ninogg', '$escuelanino', '$rf1nmb', '$rf1direcc', '$rf1nro', '$rf1parent', '1', '$fepe') ")) {
                paternalia_query(1, "INSERT INTO $db_general.pagos(folioRelacionado, cantidad, mes, dia, anio, concepto) VALUES ('$id','$aportacionInicial','$mesfechaman','$diafechaman','$aniofechaman','Primer pago')");
                paternalia_query(1, "DELETE FROM $db_general.pedidos WHERE id = " . $_GET["verificar"]);
                foreach (array_column($material, 'clave_mat') as $item) {
                    $almacen_arreglo = paternalia_query(3, "SELECT cantidad_mat, en_pedido, en_venta FROM $db_general.almacen WHERE clave_mat = '$item'");
                    $en_fisico_existente = $almacen_arreglo["cantidad_mat"] - 1;
                    $en_pedido_existente = $almacen_arreglo["en_pedido"] - 1;
                    $en_venta_existente = $almacen_arreglo["en_venta"] + 1;
                    paternalia_query(1, "UPDATE $db_general.almacen SET cantidad_mat = '$en_fisico_existente', en_pedido = '$en_pedido_existente', en_venta = '$en_venta_existente' WHERE clave_mat = '$item'");
                }
                $success = 'perfecto';
            }
        }



        echo json_encode(["respuesta" => 'Has verificado con éxito el pedido', "tipo" => 'success']);
        exit();
    }
    exit();
}
if (isset($_GET["consulta"])) {
    if ($_GET["consulta"] == '020410') {
        echo paternalia_query(2, "SELECT id, nombre, numero, direccion, municipio, costoTotal FROM $db_general.pedidos");
    }
    exit();
}
