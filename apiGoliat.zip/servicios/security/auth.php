<?php
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/headers.php';
include './jwt.php';

$data = json_decode(file_get_contents("php://input"), true);
$db_general = 'goliat';


// Establece el límite máximo de intentos y el tiempo de bloqueo en segundos
$maxIntentos = 5;
$tiempoBloqueo = 300; // 15 minutos = 900 segundos

// Obtiene la dirección IP del cliente (puede cambiar dependiendo de tu configuración)
$ip = $_SERVER['REMOTE_ADDR'];

// Verifica si esta dirección IP ha superado el límite de intentos en el tiempo de bloqueo
$resultadoIntentos = paternalia_query(3, "SELECT COUNT(*) AS intentos FROM $db_general.intentos_login WHERE ip = '$ip' AND timestamp > NOW() - $tiempoBloqueo");

if ($resultadoIntentos) {
    $intentos = $resultadoIntentos['intentos'];

    if ($intentos >= $maxIntentos) {
        // El usuario ha superado el límite de intentos, muestra un mensaje de bloqueo
        echo json_encode(['respuesta' => 'Has intentado demasiadas veces, espera un momento', 'tipo' => 'error']);
    } else {
        // El usuario no ha superado el límite de intentos, procede con la verificación de contraseña
        $password_write = $data['user_pass'];
        $username = $data['user_name'];

        // Valida y limpia los datos de entrada (por ejemplo, usando mysqli_real_escape_string si estás usando MySQL)
        $username = mysqli_real_escape_string($connect, $username);

        // Consulta la base de datos para obtener el hash y la sal
        $resultado = paternalia_query(3, "SELECT up.password, cpp.real_password, ud.user_id, ud.name, first_last_name, second_last_name FROM $db_general.users_passwords up
                                          INNER JOIN $db_general.cat_password_parameters cpp ON up.user_id = cpp.user_id
                                          INNER JOIN $db_general.users_data ud on ud.user_id = cpp.user_id
                                          WHERE user_name = '$username'");

        if ($resultado) {
            $hash = $resultado['password'];
            $salt = $resultado['real_password'];
            $username_from_database = $resultado['name'];
            $last_name_1 = $resultado['first_last_name'];
            $last_name_2 = $resultado['second_last_name'];
            $id_user_from_database = $resultado['user_id'];

            // Combina la contraseña ingresada con la sal y verifica si coincide con el hash almacenado
            $contraseña_con_salt = $password_write . $salt;

            if (password_verify($contraseña_con_salt, $hash)) {
                // Contraseña correcta, restablece los intentos de inicio de sesión
                paternalia_query(1, "DELETE FROM $db_general.intentos_login WHERE ip = '$ip'");
                /* paternalia_query(1, "INSERT INTO $db_general.logueados(id, ip, username) VALUES('$id_user_from_database', '$ip', '$username_from_database')"); */

                $data = array(
                    'user_name' => $id_user_from_database,
                    'names' => $username_from_database,
                    'second_name' => $last_name_1,
                    'third_name' => $last_name_2
                );

                $jwt = createJWT($data);
                echo json_encode(['respuesta' => "Bienvenido $username_from_database", "tipo" => "success", "jwt" => $jwt]);
            } else {
                // Contraseña incorrecta, registra un intento fallido
                paternalia_query(1, "INSERT INTO $db_general.intentos_login (ip, timestamp) VALUES ('$ip', NOW())");
                echo json_encode(['respuesta' => 'La contraseña es incorrecta', 'tipo' => 'error']);
            }
        } else {
            echo 'Usuario no encontrado';
        }
    }
} else {
    // Error al consultar los intentos de inicio de sesión, maneja la situación
    echo 'Error en la base de datos. Por favor, inténtalo de nuevo más tarde.';
}
