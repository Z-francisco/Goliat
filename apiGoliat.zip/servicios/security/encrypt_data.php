<?php
// Genera un par de claves pública y privada
$resource = openssl_pkey_new(array(
    "private_key_bits" => 2048,  // Tamaño de la clave privada en bits
    "private_key_type" => OPENSSL_KEYTYPE_RSA  // Tipo de clave: RSA
));

// Obtiene la clave pública
openssl_pkey_export($resource, $privateKey);

// Obtén la clave pública a partir de la clave privada
$details = openssl_pkey_get_details($resource);
$publicKey = $details["key"];

// Datos a cifrar
$data = "Esto es un mensaje secreto";

// Cifra los datos utilizando la clave pública
openssl_public_encrypt($data, $encryptedData, $publicKey);

// Simula el almacenamiento de los datos cifrados (en un entorno real, deberías guardarlos de forma segura)
$datosCifradosAlmacenados = $encryptedData;

// Descifra los datos utilizando la clave privada
openssl_private_decrypt($datosCifradosAlmacenados, $decryptedData, $privateKey);

// Imprime los resultados
echo "Mensaje original: " . $data . "<br>";
echo "Mensaje cifrado: " . base64_encode($encryptedData) . "<br>";  // Mostrar datos cifrados en base64
echo "Mensaje descifrado: " . $decryptedData . "<br>";
