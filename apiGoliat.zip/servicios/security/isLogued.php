<?php
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/headers.php';
require_once './global_functions.php';

$ip = $_SERVER['REMOTE_ADDR'];
//no guardar info del usuario en front, sino en back guardar la ip para verificar que usuario tiene logueado, borrar el registro de logueados de la ip de la que se realice el cierre de sesion para evitar confusiones o choques de usuario, esta funcion se llamará cada que se necesite hacer uso de los roles, tambien esto afectará a front, no se almacenaran ahi los roles, sino que se realizara una peticion que devuelva true or false en la funcion donde se extraigan los datos, de esta manera conceder o no conceder los accesos a los componentes administrador, usuario, contable o asi

echo isLogued($ip);
