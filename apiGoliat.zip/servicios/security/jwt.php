<?php
include '../../vendor/autoload.php';
use \Firebase\JWT\JWT;
use \Firebase\JWT\Key;

function createJWT($data) {
    $secretKey = 'tu_clave_secreta'; // Clave secreta para firmar el token
    $issuedAt = time();
    $expirationTime = $issuedAt + 3600*3; // 60 segundos = 1 minuto
    $payload = array(
        'iat' => $issuedAt,
        'exp' => $expirationTime,
        'data' => $data
    );

    $jwt = JWT::encode($payload, $secretKey, 'HS256');
    return $jwt;
}

function verifyJWT($token) {
    $secretKey = 'tu_clave_secreta'; // Clave secreta para verificar el token
    try {
        $decoded = JWT::decode($token, new Key($secretKey, 'HS256'));
        return (array) $decoded->data; // Devolver los datos decodificados
    } catch (Exception $e) {
        return false; // El token no es válido
    }
}

?>