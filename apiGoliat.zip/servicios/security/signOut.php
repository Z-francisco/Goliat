<?php
require_once '../../debug/global_sql_functions.php';
require_once '../../debug/headers.php';
require_once './global_functions.php';

$ip = $_SERVER['REMOTE_ADDR'];

echo json_encode(signOut($ip));